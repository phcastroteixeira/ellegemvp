import { create } from 'zustand';
import { Parameter } from '../types';

type ParameterState = {
  parameters: Parameter[];
  isLoading: boolean;
  error: string | null;
  fetchParameters: () => Promise<void>;
  getParameter: (month: number, year: number) => Parameter | undefined;
  addParameter: (parameter: Omit<Parameter, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateParameter: (id: string, parameter: Partial<Parameter>) => Promise<void>;
  deleteParameter: (id: string) => Promise<void>;
};

// Mock data for demonstration
const mockParameters: Parameter[] = [
  {
    id: '1',
    month: 10,
    year: 2024,
    utilityRate: 0.75,
    publicLightingFee: 25.50,
    saleValue: 0.65,
    minimumRate: 30.00,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    month: 9,
    year: 2024,
    utilityRate: 0.72,
    publicLightingFee: 25.50,
    saleValue: 0.62,
    minimumRate: 30.00,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const useParameterStore = create<ParameterState>((set, get) => ({
  parameters: [],
  isLoading: false,
  error: null,
  
  fetchParameters: async () => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      set({ parameters: mockParameters, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch parameters', isLoading: false });
    }
  },
  
  getParameter: (month: number, year: number) => {
    return get().parameters.find(param => param.month === month && param.year === year);
  },
  
  addParameter: async (parameterData) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Check if parameter for this month/year already exists
      const exists = get().parameters.some(
        param => param.month === parameterData.month && param.year === parameterData.year
      );
      
      if (exists) {
        throw new Error('Parameter for this month and year already exists');
      }
      
      const newParameter: Parameter = {
        ...parameterData,
        id: Math.random().toString(36).substring(2, 11),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set(state => ({
        parameters: [...state.parameters, newParameter],
        isLoading: false,
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to add parameter', 
        isLoading: false 
      });
    }
  },
  
  updateParameter: async (id: string, parameterData) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      set(state => ({
        parameters: state.parameters.map(parameter => 
          parameter.id === id
            ? { ...parameter, ...parameterData, updatedAt: new Date().toISOString() }
            : parameter
        ),
        isLoading: false,
      }));
    } catch (error) {
      set({ error: 'Failed to update parameter', isLoading: false });
    }
  },
  
  deleteParameter: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      set(state => ({
        parameters: state.parameters.filter(parameter => parameter.id !== id),
        isLoading: false,
      }));
    } catch (error) {
      set({ error: 'Failed to delete parameter', isLoading: false });
    }
  },
}));