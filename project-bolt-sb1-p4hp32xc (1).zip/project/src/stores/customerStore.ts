import { create } from 'zustand';
import { Customer } from '../types';

type CustomerState = {
  customers: Customer[];
  isLoading: boolean;
  error: string | null;
  fetchCustomers: () => Promise<void>;
  getCustomer: (id: string) => Customer | undefined;
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateCustomer: (id: string, customer: Partial<Customer>) => Promise<void>;
  deleteCustomer: (id: string) => Promise<void>;
};

// Mock data for demonstration
const mockCustomers: Customer[] = [
  {
    id: '1',
    name: 'João Silva',
    email: 'joao.silva@example.com',
    phone: '(11) 98765-4321',
    consumerUnit: '12345678',
    address: 'Rua das Flores, 123',
    zipCode: '01234-567',
    city: 'São Paulo',
    state: 'SP',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Maria Oliveira',
    email: 'maria.oliveira@example.com',
    phone: '(21) 98765-4321',
    consumerUnit: '87654321',
    address: 'Av. Principal, 456',
    zipCode: '20000-000',
    city: 'Rio de Janeiro',
    state: 'RJ',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const useCustomerStore = create<CustomerState>((set, get) => ({
  customers: [],
  isLoading: false,
  error: null,
  
  fetchCustomers: async () => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      set({ customers: mockCustomers, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch customers', isLoading: false });
    }
  },
  
  getCustomer: (id: string) => {
    return get().customers.find(customer => customer.id === id);
  },
  
  addCustomer: async (customerData) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newCustomer: Customer = {
        ...customerData,
        id: Math.random().toString(36).substring(2, 11),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      set(state => ({
        customers: [...state.customers, newCustomer],
        isLoading: false,
      }));
    } catch (error) {
      set({ error: 'Failed to add customer', isLoading: false });
    }
  },
  
  updateCustomer: async (id: string, customerData) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      set(state => ({
        customers: state.customers.map(customer => 
          customer.id === id
            ? { ...customer, ...customerData, updatedAt: new Date().toISOString() }
            : customer
        ),
        isLoading: false,
      }));
    } catch (error) {
      set({ error: 'Failed to update customer', isLoading: false });
    }
  },
  
  deleteCustomer: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      set(state => ({
        customers: state.customers.filter(customer => customer.id !== id),
        isLoading: false,
      }));
    } catch (error) {
      set({ error: 'Failed to delete customer', isLoading: false });
    }
  },
}));