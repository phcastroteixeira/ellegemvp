import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '../types';

type AuthState = {
  isAuthenticated: boolean;
  user: User | null;
  login: (credentials: { email: string; password: string }) => boolean;
  logout: () => void;
};

// Mock users for demonstration
const mockUsers = [
  {
    id: '1',
    name: 'Pedro Silva',
    email: 'pedro@megalu.com.br',
    role: 'admin' as const,
    password: 'Mgu@2020',
  },
  {
    id: '2',
    name: 'João Silva',
    email: 'cliente@example.com',
    role: 'client' as const,
    password: 'password',
  },
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      user: null,
      login: (credentials) => {
        const user = mockUsers.find(u => 
          u.email === credentials.email && u.password === credentials.password
        );
        
        if (user) {
          const { password, ...userWithoutPassword } = user;
          set({ 
            isAuthenticated: true, 
            user: userWithoutPassword 
          });
          return true;
        }
        return false;
      },
      logout: () => set({ isAuthenticated: false, user: null }),
    }),
    {
      name: 'auth-storage',
    }
  )
);