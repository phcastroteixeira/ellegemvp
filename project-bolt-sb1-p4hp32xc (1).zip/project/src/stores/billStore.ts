import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Bill } from '../types';

type BillState = {
  bills: Bill[];
  isLoading: boolean;
  error: string | null;
  fetchBills: () => Promise<void>;
  fetchCustomerBills: (customerId: string) => Promise<void>;
  getBill: (id: string) => Bill | undefined;
  addBill: (bill: Omit<Bill, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateBill: (id: string, bill: Partial<Bill>) => Promise<void>;
  deleteBill: (id: string) => Promise<void>;
};

// Mock data for demonstration
const mockBills: Bill[] = [
  {
    id: '1',
    customerId: '1',
    month: 1,
    year: 2024,
    autoConsumption: 600,
    receivedCredit: 500,
    totalReading: 1100,
    utilityRate: 0.845757,
    saleValue: 0.74,
    accumulatedCredit: 0,
    receivedValue: 814.00,
    accumulatedValue: 0,
    publicLightingFee: 116.33,
    issueDate: '2024-01-15T00:00:00.000Z',
    minimumRate: 84.58,
    dueDate: '2024-02-10T00:00:00.000Z',
    initialReadingDate: '2024-01-01T00:00:00.000Z',
    readingDate: '2024-01-31T00:00:00.000Z',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const useBillStore = create<BillState>()(
  persist(
    (set, get) => ({
      bills: [],
      isLoading: false,
      error: null,
      
      fetchBills: async () => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // Only set mock data if no bills exist
          if (get().bills.length === 0) {
            set({ bills: mockBills });
          }
          
          set({ isLoading: false });
        } catch (error) {
          set({ error: 'Failed to fetch bills', isLoading: false });
          throw error;
        }
      },
      
      fetchCustomerBills: async (customerId: string) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          const customerBills = get().bills.filter(bill => bill.customerId === customerId);
          set({ bills: customerBills, isLoading: false });
        } catch (error) {
          set({ error: 'Failed to fetch customer bills', isLoading: false });
          throw error;
        }
      },
      
      getBill: (id: string) => {
        return get().bills.find(bill => bill.id === id);
      },
      
      addBill: async (billData) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          const newBill: Bill = {
            ...billData,
            id: Math.random().toString(36).substring(2, 11),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          
          set(state => ({
            bills: [...state.bills, newBill],
            isLoading: false,
          }));
        } catch (error) {
          set({ error: 'Failed to add bill', isLoading: false });
          throw error;
        }
      },
      
      updateBill: async (id: string, billData) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            bills: state.bills.map(bill => 
              bill.id === id
                ? { ...bill, ...billData, updatedAt: new Date().toISOString() }
                : bill
            ),
            isLoading: false,
          }));
        } catch (error) {
          set({ error: 'Failed to update bill', isLoading: false });
          throw error;
        }
      },
      
      deleteBill: async (id: string) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 500));
          
          set(state => ({
            bills: state.bills.filter(bill => bill.id !== id),
            isLoading: false,
          }));
        } catch (error) {
          set({ error: 'Failed to delete bill', isLoading: false });
          throw error;
        }
      },
    }),
    {
      name: 'bills-storage',
    }
  )
);