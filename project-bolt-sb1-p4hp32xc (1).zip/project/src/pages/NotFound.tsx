import React from 'react';
import { Link } from 'react-router-dom';
import { Zap, Home } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-4">
      <div className="text-center">
        <div className="mb-6 flex justify-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary-500">
            <Zap size={32} className="text-white" />
          </div>
        </div>
        
        <h1 className="mb-4 text-9xl font-bold text-primary-500">404</h1>
        <h2 className="mb-6 text-2xl font-semibold text-gray-800">Página não encontrada</h2>
        <p className="mb-8 text-gray-600">
          A página que você está procurando pode ter sido removida, renomeada ou está temporariamente indisponível.
        </p>
        
        <Link 
          to="/" 
          className="inline-flex items-center rounded-md bg-primary-500 px-6 py-3 text-white transition-colors hover:bg-primary-600"
        >
          <Home size={18} className="mr-2" />
          Voltar para a página inicial
        </Link>
      </div>
      
      <div className="absolute bottom-0 left-0 h-16 w-full bg-primary-500 opacity-5"></div>
      <div className="absolute bottom-0 left-0 h-8 w-full bg-accent-400 opacity-5"></div>
    </div>
  );
};

export default NotFound;