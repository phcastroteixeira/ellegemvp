import React, { useEffect, useState } from 'react';
import { 
  Search, Download, Calendar, CreditCard, ChevronLeft, 
  ChevronRight, FileText, Eye, Filter
} from 'lucide-react';
import { useBillStore } from '../../stores/billStore';
import Loader from '../../components/ui/Loader';
import { MONTHS, Bill } from '../../types';
import { format } from 'date-fns';

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  switch (status) {
    case 'pending':
      return <span className="badge-warning">Pendente</span>;
    case 'paid':
      return <span className="badge-success">Pago</span>;
    case 'overdue':
      return <span className="badge-error">Atrasado</span>;
    default:
      return <span className="badge">{status}</span>;
  }
};

const ClientBills: React.FC = () => {
  const { bills, fetchBills, isLoading, error } = useBillStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // For demo purposes, we'll set a fake customerId for the client
  const DEMO_CUSTOMER_ID = '1';

  useEffect(() => {
    fetchBills();
  }, [fetchBills]);

  // Get month name
  const getMonthName = (month: number) => {
    return MONTHS.find(m => m.value === month)?.label || 'Mês inválido';
  };

  // Filter bills based on search term and status filter
  const filteredBills = bills
    .filter(bill => bill.customerId === DEMO_CUSTOMER_ID)
    .filter(bill => {
      if (statusFilter !== 'all') {
        return bill.status === statusFilter;
      }
      return true;
    })
    .filter(bill => {
      const monthYear = `${getMonthName(bill.month)} ${bill.year}`.toLowerCase();
      const amount = (bill.totalAmount ?? 0).toString();
      
      return (
        monthYear.includes(searchTerm.toLowerCase()) ||
        amount.includes(searchTerm)
      );
    });

  // Sort bills by date (most recent first)
  const sortedBills = [...filteredBills].sort((a, b) => {
    const dateA = new Date(`${a.year}-${a.month}-01`);
    const dateB = new Date(`${b.year}-${b.month}-01`);
    return dateB.getTime() - dateA.getTime();
  });

  // Pagination
  const indexOfLastBill = currentPage * itemsPerPage;
  const indexOfFirstBill = indexOfLastBill - itemsPerPage;
  const currentBills = sortedBills.slice(indexOfFirstBill, indexOfLastBill);
  const totalPages = Math.ceil(sortedBills.length / itemsPerPage);
  
  const viewBillDetails = (bill: Bill) => {
    setSelectedBill(bill);
  };
  
  const closeModal = () => {
    setSelectedBill(null);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Minhas Faturas</h1>
        <p className="text-gray-600">Visualize e gerencie suas faturas de energia</p>
      </div>

      {/* Search and filter */}
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full md:w-64">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="form-input pl-10"
            placeholder="Buscar por período ou valor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter size={18} className="text-gray-500" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="form-input"
          >
            <option value="all">Todos os status</option>
            <option value="pending">Pendentes</option>
            <option value="paid">Pagas</option>
            <option value="overdue">Atrasadas</option>
          </select>
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader label="Carregando faturas..." />
        </div>
      ) : error ? (
        <div className="rounded-md bg-error-50 p-4 text-error-700">
          <p>{error}</p>
        </div>
      ) : sortedBills.length === 0 ? (
        <div className="rounded-md bg-gray-50 p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gray-100">
            <FileText size={24} className="text-gray-400" />
          </div>
          <h3 className="mb-2 text-lg font-medium text-gray-700">Nenhuma fatura encontrada</h3>
          <p className="text-gray-500">
            {searchTerm || statusFilter !== 'all'
              ? 'Tente ajustar os filtros de busca'
              : 'Você ainda não possui faturas cadastradas'
            }
          </p>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {currentBills.map((bill) => (
              <div 
                key={bill.id} 
                className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm transition-all hover:shadow-md"
              >
                <div className="border-b border-gray-100 bg-gray-50 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center">
                      <Calendar size={18} className="mr-2 text-gray-500" />
                      <span className="font-medium text-gray-700">
                        {getMonthName(bill.month)} {bill.year}
                      </span>
                    </div>
                    <StatusBadge status={bill.status} />
                  </div>
                </div>
                
                <div className="p-4">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <div className="text-sm text-gray-500">Consumo</div>
                      <div className="font-medium text-gray-900">{bill.energyConsumption} kWh</div>
                    </div>
                    
                    <div>
                      <div className="text-sm text-gray-500">Valor Total</div>
                      <div className="text-lg font-semibold text-gray-900">
                        R$ {(bill.totalAmount ?? 0).toFixed(2)}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-sm text-gray-500">Vencimento</div>
                      <div className="font-medium text-gray-900">
                        {format(new Date(bill.dueDate), 'dd/MM/yyyy')}
                      </div>
                    </div>
                    
                    <div className="ml-auto flex items-center space-x-2">
                      <button
                        onClick={() => viewBillDetails(bill)}
                        className="rounded-md bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary-600 transition-colors hover:bg-primary-100"
                      >
                        <Eye size={14} className="mr-1 inline" />
                        Visualizar
                      </button>
                      
                      <button
                        onClick={() => alert('Funcionalidade em desenvolvimento')}
                        className="rounded-md bg-gray-50 px-3 py-1.5 text-xs font-medium text-gray-600 transition-colors hover:bg-gray-100"
                      >
                        <Download size={14} className="mr-1 inline" />
                        Baixar
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-6 flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Mostrando {indexOfFirstBill + 1} a {Math.min(indexOfLastBill, sortedBills.length)} de {sortedBills.length} faturas
              </div>
              <div className="flex space-x-1">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`rounded-md p-2 ${
                    currentPage === 1
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronLeft size={18} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i + 1}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`rounded-md px-3 py-1 ${
                      currentPage === i + 1
                        ? 'bg-primary-50 text-primary-600 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className={`rounded-md p-2 ${
                    currentPage === totalPages
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}
        </>
      )}
      
      {/* Bill details modal */}
      {selectedBill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 transition-opacity"
            onClick={closeModal}
          ></div>
          
          <div className="relative z-50 w-full max-w-2xl rounded-lg bg-white p-6 shadow-xl">
            <button
              onClick={closeModal}
              className="absolute right-4 top-4 rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-500"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="20" 
                height="20" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
            
            <div className="mb-6 text-center">
              <h3 className="text-xl font-semibold text-gray-900">
                Fatura - {getMonthName(selectedBill.month)}/{selectedBill.year}
              </h3>
              <div className="mt-1 text-gray-500">
                Unidade consumidora: 12345678
              </div>
              <div className="mt-4">
                <StatusBadge status={selectedBill.status} />
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="rounded-lg bg-gray-50 p-4">
                  <h4 className="mb-3 text-sm font-medium text-gray-500">Detalhes do Consumo</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Consumo Total</span>
                      <span className="font-medium text-gray-900">{selectedBill.energyConsumption} kWh</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Taxa da Concessionária</span>
                      <span className="font-medium text-gray-900">R$ {(selectedBill.utilityRate ?? 0).toFixed(2)}/kWh</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Valor do Consumo</span>
                      <span className="font-medium text-gray-900">
                        R$ {((selectedBill.energyConsumption ?? 0) * (selectedBill.utilityRate ?? 0)).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-lg bg-gray-50 p-4">
                  <h4 className="mb-3 text-sm font-medium text-gray-500">Taxas Adicionais</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Iluminação Pública</span>
                      <span className="font-medium text-gray-900">R$ {(selectedBill.publicLightingFee ?? 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Outros</span>
                      <span className="font-medium text-gray-900">R$ 0,00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Juros/Multa</span>
                      <span className="font-medium text-gray-900">R$ 0,00</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="rounded-lg bg-primary-50 p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-primary-700">Valor Total</h4>
                    <p className="mt-1 text-2xl font-bold text-primary-700">
                      R$ {(selectedBill.totalAmount ?? 0).toFixed(2)}
                    </p>
                  </div>
                  
                  <div className="text-right">
                    <h4 className="text-sm font-medium text-primary-700">Vencimento</h4>
                    <p className="mt-1 text-xl font-medium text-primary-700">
                      {format(new Date(selectedBill.dueDate), 'dd/MM/yyyy')}
                    </p>
                  </div>
                </div>
              </div>
              
              {selectedBill.status === 'paid' && selectedBill.paidDate && (
                <div className="rounded-lg bg-success-50 p-4">
                  <div className="flex items-center">
                    <CreditCard size={18} className="mr-2 text-success-700" />
                    <span className="text-success-700">
                      Pagamento realizado em {format(new Date(selectedBill.paidDate), 'dd/MM/yyyy')}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="flex justify-end space-x-3">
                <button
                  onClick={closeModal}
                  className="btn-outline"
                >
                  Fechar
                </button>
                <button
                  onClick={() => alert('Funcionalidade em desenvolvimento')}
                  className="btn-primary"
                >
                  <Download size={18} className="mr-2" />
                  Baixar PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientBills;