import React, { useEffect, useState } from 'react';
import { 
  Zap, FileText, TrendingDown, AlertTriangle, ArrowRight,
  Calendar, Lightbulb, DollarSign, Bolt
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useBillStore } from '../../stores/billStore';
import { useAuthStore } from '../../stores/authStore';
import DataChart from '../../components/ui/DataChart';
import Loader from '../../components/ui/Loader';
import { MONTHS } from '../../types';
import { format } from 'date-fns';

const ClientDashboard: React.FC = () => {
  const { bills, fetchBills, isLoading } = useBillStore();
  const { user } = useAuthStore();
  const [monthlyConsumption, setMonthlyConsumption] = useState<{label: string; value: number}[]>([]);

  // For demo purposes, we'll set a fake customerId for the client
  const DEMO_CUSTOMER_ID = '1';

  useEffect(() => {
    const loadData = async () => {
      await fetchBills();
    };
    
    loadData();
  }, [fetchBills]);

  useEffect(() => {
    if (bills.length > 0) {
      // Filter bills for this client
      const clientBills = bills.filter(bill => bill.customerId === DEMO_CUSTOMER_ID);
      
      // Get consumption by month for the chart
      const currentYear = new Date().getFullYear();
      const consumptionByMonth = Array(12).fill(0);
      
      clientBills.forEach(bill => {
        if (bill.year === currentYear) {
          consumptionByMonth[bill.month - 1] = bill.energyConsumption || 0;
        }
      });
      
      const chartData = MONTHS.map((month, index) => ({
        label: month.label.substring(0, 3),
        value: consumptionByMonth[index]
      }));
      
      setMonthlyConsumption(chartData);
    }
  }, [bills]);

  // Calculate statistics
  const clientBills = bills.filter(bill => bill.customerId === DEMO_CUSTOMER_ID);
  const pendingBills = clientBills.filter(bill => bill.status === 'pending');
  
  const latestBill = clientBills.length > 0
    ? clientBills.sort((a, b) => {
        const dateA = new Date(`${a.year}-${a.month}-01`);
        const dateB = new Date(`${b.year}-${b.month}-01`);
        return dateB.getTime() - dateA.getTime();
      })[0]
    : null;
  
  const previousBill = clientBills.length > 1
    ? clientBills.sort((a, b) => {
        const dateA = new Date(`${a.year}-${a.month}-01`);
        const dateB = new Date(`${b.year}-${b.month}-01`);
        return dateB.getTime() - dateA.getTime();
      })[1]
    : null;
  
  // Calculate consumption change percentage with null checks
  const consumptionChange = latestBill && previousBill && previousBill.energyConsumption
    ? ((latestBill.energyConsumption - previousBill.energyConsumption) / previousBill.energyConsumption) * 100
    : 0;
  
  // Calculate average consumption with null check
  const averageConsumption = clientBills.length > 0
    ? clientBills.reduce((sum, bill) => sum + (bill?.energyConsumption || 0), 0) / clientBills.length
    : 0;
  
  // Format consumption trend
  const consumptionTrend = {
    isUp: consumptionChange > 0,
    value: Math.abs(consumptionChange).toFixed(1)
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader size="large" label="Carregando dados do dashboard..." />
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Bem-vindo de volta, {user?.name || 'Cliente'}</p>
      </div>
      
      {/* Quick summary cards */}
      <div className="mb-8 grid gap-4 md:grid-cols-3">
        <div className="card">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary-50">
            <Zap size={20} className="text-secondary-500" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-gray-900">Consumo Atual</h3>
          <p className="mt-1 text-3xl font-bold text-gray-900">
            {latestBill ? `${latestBill.energyConsumption || 0} kWh` : '0 kWh'}
            <span className={`ml-2 text-sm font-normal ${
              consumptionTrend.isUp ? 'text-error-500' : 'text-success-500'
            }`}>
              {consumptionTrend.isUp ? '↑' : '↓'} {consumptionTrend.value}%
            </span>
          </p>
          <p className="mt-1 text-sm text-gray-500">
            Média: {averageConsumption.toFixed(0)} kWh/mês
          </p>
        </div>
        
        <div className="card">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent-50">
            <FileText size={20} className="text-accent-400" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-gray-900">Faturas Pendentes</h3>
          <p className="mt-1 text-3xl font-bold text-gray-900">
            {pendingBills.length}
          </p>
          {pendingBills.length > 0 && (
            <div className="mt-2">
              <Link to="/bills" className="text-sm font-medium text-primary-500 hover:text-primary-600">
                Ver detalhes <ArrowRight size={14} className="ml-1 inline" />
              </Link>
            </div>
          )}
        </div>
        
        <div className="card">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-error-50">
            <AlertTriangle size={20} className="text-error-500" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-gray-900">Próximo Vencimento</h3>
          {pendingBills.length > 0 ? (
            <>
              <p className="mt-1 text-3xl font-bold text-gray-900">
                {format(new Date(pendingBills[0].dueDate), 'dd/MM/yyyy')}
              </p>
              <p className="mt-1 text-sm text-gray-500">
                R$ {pendingBills[0].totalAmount?.toFixed(2) || '0.00'}
              </p>
            </>
          ) : (
            <p className="mt-1 text-xl font-medium text-gray-500">
              Não há faturas pendentes
            </p>
          )}
        </div>
      </div>
      
      {/* Latest bill details */}
      {latestBill && (
        <div className="mb-8">
          <h2 className="mb-4 text-xl font-semibold text-gray-900">Última Fatura</h2>
          <div className="rounded-lg border border-gray-200 bg-white overflow-hidden">
            <div className="border-b border-gray-200 bg-gray-50 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center">
                  <Calendar size={18} className="mr-2 text-gray-500" />
                  <span className="font-medium text-gray-700">
                    {MONTHS.find(m => m.value === latestBill.month)?.label} {latestBill.year}
                  </span>
                </div>
                <div className={`rounded-full px-3 py-1 text-xs font-medium ${
                  latestBill.status === 'paid' 
                    ? 'bg-success-50 text-success-700' 
                    : latestBill.status === 'overdue'
                      ? 'bg-error-50 text-error-700'
                      : 'bg-warning-50 text-warning-700'
                }`}>
                  {latestBill.status === 'paid' 
                    ? 'Pago' 
                    : latestBill.status === 'overdue'
                      ? 'Atrasado'
                      : 'Pendente'
                  }
                </div>
              </div>
            </div>
            
            <div className="p-4">
              <div className="grid gap-8 md:grid-cols-3">
                <div>
                  <div className="flex items-center text-gray-600">
                    <Bolt size={18} className="mr-2" />
                    <p>Consumo</p>
                  </div>
                  <p className="mt-1 text-2xl font-semibold text-gray-900">
                    {latestBill.energyConsumption || 0} kWh
                  </p>
                </div>
                
                <div>
                  <div className="flex items-center text-gray-600">
                    <Lightbulb size={18} className="mr-2" />
                    <p>Iluminação Pública</p>
                  </div>
                  <p className="mt-1 text-2xl font-semibold text-gray-900">
                    R$ {latestBill.publicLightingFee?.toFixed(2) || '0.00'}
                  </p>
                </div>
                
                <div>
                  <div className="flex items-center text-gray-600">
                    <DollarSign size={18} className="mr-2" />
                    <p>Valor Total</p>
                  </div>
                  <p className="mt-1 text-2xl font-semibold text-gray-900">
                    R$ {latestBill.totalAmount?.toFixed(2) || '0.00'}
                  </p>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <Link 
                  to="/bills"
                  className="rounded-md bg-primary-50 px-4 py-2 text-sm font-medium text-primary-600 transition-colors hover:bg-primary-100"
                >
                  Ver todas as faturas
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Consumption chart */}
      <div className="card">
        <h2 className="mb-2 text-xl font-semibold text-gray-900">Histórico de Consumo</h2>
        <p className="mb-6 text-gray-600">Seu consumo mensal de energia em kWh</p>
        
        <DataChart 
          data={monthlyConsumption}
          title="Consumo em kWh"
          height={250}
          barColor="#0F4C81"
        />
        
        {/* Energy saving tips */}
        <div className="mt-8 rounded-lg border border-green-200 bg-green-50 p-4">
          <h3 className="mb-2 font-medium text-green-800">Dicas para Economizar Energia</h3>
          <ul className="space-y-2 text-sm text-green-700">
            <li className="flex items-start">
              <TrendingDown size={16} className="mr-2 mt-0.5 flex-shrink-0" />
              <span>Use lâmpadas LED, que consomem até 85% menos energia que as incandescentes.</span>
            </li>
            <li className="flex items-start">
              <TrendingDown size={16} className="mr-2 mt-0.5 flex-shrink-0" />
              <span>Desligue aparelhos da tomada quando não estiverem em uso.</span>
            </li>
            <li className="flex items-start">
              <TrendingDown size={16} className="mr-2 mt-0.5 flex-shrink-0" />
              <span>Utilize o ar-condicionado na temperatura adequada (23°C-24°C).</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;