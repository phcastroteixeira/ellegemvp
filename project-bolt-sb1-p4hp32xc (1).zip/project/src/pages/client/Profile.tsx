import React, { useState } from 'react';
import { 
  User, Mail, Phone, Home, MapPin, Shield,
  Save, AlertCircle, Lock, Eye, EyeOff
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { z } from 'zod';

const profileSchema = z.object({
  name: z.string().min(3, 'Nome deve ter pelo menos 3 caracteres'),
  email: z.string().email('Email inválido'),
  phone: z.string().min(10, 'Telefone inválido'),
  address: z.string().min(5, 'Endereço deve ter pelo menos 5 caracteres'),
  zipCode: z.string().regex(/^\d{5}-?\d{3}$/, 'CEP inválido'),
  city: z.string().min(3, 'Cidade deve ter pelo menos 3 caracteres'),
  state: z.string().length(2, 'Estado inválido'),
});

const passwordSchema = z.object({
  currentPassword: z.string().min(6, 'A senha atual deve ter pelo menos 6 caracteres'),
  newPassword: z.string().min(6, 'A nova senha deve ter pelo menos 6 caracteres'),
  confirmPassword: z.string().min(6, 'Confirme a nova senha'),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: 'As senhas não coincidem',
  path: ['confirmPassword'],
});

type ProfileFormData = z.infer<typeof profileSchema>;
type PasswordFormData = z.infer<typeof passwordSchema>;

const ClientProfile: React.FC = () => {
  const { user } = useAuthStore();
  
  const [profileData, setProfileData] = useState<ProfileFormData>({
    name: user?.name || 'João Silva',
    email: user?.email || 'joao.silva@example.com',
    phone: '(11) 98765-4321',
    address: 'Rua das Flores, 123',
    zipCode: '01234-567',
    city: 'São Paulo',
    state: 'SP',
  });
  
  const [passwordData, setPasswordData] = useState<PasswordFormData>({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const [profileErrors, setProfileErrors] = useState<Partial<ProfileFormData>>({});
  const [passwordErrors, setPasswordErrors] = useState<Partial<PasswordFormData>>({});
  const [profileSuccess, setProfileSuccess] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [profileSubmitting, setProfileSubmitting] = useState(false);
  const [passwordSubmitting, setPasswordSubmitting] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const formatPhoneNumber = (value: string) => {
    // Remove non-numeric characters
    const numbers = value.replace(/\D/g, '');
    
    // Format as (XX) XXXXX-XXXX
    if (numbers.length <= 2) {
      return numbers;
    } else if (numbers.length <= 7) {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    } else {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
    }
  };
  
  const formatZipCode = (value: string) => {
    // Remove non-numeric characters
    const numbers = value.replace(/\D/g, '');
    
    // Format as XXXXX-XXX
    if (numbers.length <= 5) {
      return numbers;
    } else {
      return `${numbers.slice(0, 5)}-${numbers.slice(5, 8)}`;
    }
  };
  
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'phone') {
      setProfileData(prev => ({ ...prev, phone: formatPhoneNumber(value) }));
    } else if (name === 'zipCode') {
      setProfileData(prev => ({ ...prev, zipCode: formatZipCode(value) }));
    } else {
      setProfileData(prev => ({ ...prev, [name]: value }));
    }
  };
  
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
  };
  
  const validateProfileForm = (): boolean => {
    try {
      profileSchema.parse(profileData);
      setProfileErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Partial<ProfileFormData> = {};
        error.errors.forEach((err) => {
          if (err.path[0] as keyof ProfileFormData) {
            newErrors[err.path[0] as keyof ProfileFormData] = err.message;
          }
        });
        setProfileErrors(newErrors);
      }
      return false;
    }
  };
  
  const validatePasswordForm = (): boolean => {
    try {
      passwordSchema.parse(passwordData);
      setPasswordErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Partial<PasswordFormData> = {};
        error.errors.forEach((err) => {
          if (err.path[0] as keyof PasswordFormData) {
            newErrors[err.path[0] as keyof PasswordFormData] = err.message;
          }
        });
        setPasswordErrors(newErrors);
      }
      return false;
    }
  };
  
  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess('');
    
    if (!validateProfileForm()) return;
    
    setProfileSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setProfileSuccess('Perfil atualizado com sucesso!');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setProfileSuccess('');
      }, 3000);
    } catch (error) {
      setProfileErrors({ name: 'Ocorreu um erro ao atualizar o perfil.' });
    } finally {
      setProfileSubmitting(false);
    }
  };
  
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordSuccess('');
    
    if (!validatePasswordForm()) return;
    
    // Demo validation - in a real app, this would be an API call
    if (passwordData.currentPassword !== 'password') {
      setPasswordErrors({
        currentPassword: 'Senha atual incorreta',
      });
      return;
    }
    
    setPasswordSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setPasswordSuccess('Senha alterada com sucesso!');
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setPasswordSuccess('');
      }, 3000);
    } catch (error) {
      setPasswordErrors({ 
        currentPassword: 'Ocorreu um erro ao atualizar a senha.' 
      });
    } finally {
      setPasswordSubmitting(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Meu Perfil</h1>
        <p className="text-gray-600">Gerencie suas informações pessoais</p>
      </div>
      
      <div className="mb-8 grid gap-8 lg:grid-cols-3">
        {/* Profile sidebar */}
        <div className="lg:col-span-1">
          <div className="card">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-primary-50">
                <User size={48} className="text-primary-500" />
              </div>
              <h2 className="text-xl font-semibold text-gray-900">
                {profileData.name}
              </h2>
              <p className="text-gray-500">{profileData.email}</p>
              
              <div className="mt-6 w-full border-t border-gray-200 pt-6">
                <div className="flex items-center justify-center">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-success-50">
                    <Shield size={16} className="text-success-500" />
                  </div>
                  <span className="ml-2 text-sm text-gray-600">
                    Cliente desde Janeiro de 2024
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 rounded-lg bg-primary-50 p-4 text-sm text-primary-700">
            <p className="mb-2 font-medium">Precisa de ajuda?</p>
            <p>Entre em contato com o nosso suporte pelo telefone (11) 9999-9999 ou pelo email suporte@energyflow.com</p>
          </div>
        </div>
        
        {/* Profile forms */}
        <div className="lg:col-span-2">
          {/* Personal Information Form */}
          <div className="card mb-8">
            <h2 className="mb-6 text-xl font-semibold text-gray-900">
              Informações Pessoais
            </h2>
            
            {profileSuccess && (
              <div className="mb-6 rounded-md bg-success-50 p-3 text-success-700">
                <p>{profileSuccess}</p>
              </div>
            )}
            
            <form onSubmit={handleProfileSubmit}>
              <div className="mb-6 grid gap-6 md:grid-cols-2">
                <div>
                  <label htmlFor="name" className="form-label">Nome Completo</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <User size={16} className="text-gray-400" />
                    </div>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={profileData.name}
                      onChange={handleProfileChange}
                      className={`form-input pl-10 ${profileErrors.name ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                  </div>
                  {profileErrors.name && <p className="form-error">{profileErrors.name}</p>}
                </div>
                
                <div>
                  <label htmlFor="email" className="form-label">Email</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Mail size={16} className="text-gray-400" />
                    </div>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={profileData.email}
                      onChange={handleProfileChange}
                      className={`form-input pl-10 ${profileErrors.email ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                  </div>
                  {profileErrors.email && <p className="form-error">{profileErrors.email}</p>}
                </div>
                
                <div>
                  <label htmlFor="phone" className="form-label">Telefone</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Phone size={16} className="text-gray-400" />
                    </div>
                    <input
                      type="text"
                      id="phone"
                      name="phone"
                      value={profileData.phone}
                      onChange={handleProfileChange}
                      className={`form-input pl-10 ${profileErrors.phone ? 'border-error-500 focus:ring-error-500' : ''}`}
                      maxLength={15}
                    />
                  </div>
                  {profileErrors.phone && <p className="form-error">{profileErrors.phone}</p>}
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="mb-3 text-lg font-medium text-gray-900">Endereço</h3>
                
                <div className="mb-4">
                  <label htmlFor="address" className="form-label">Logradouro</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Home size={16} className="text-gray-400" />
                    </div>
                    <input
                      type="text"
                      id="address"
                      name="address"
                      value={profileData.address}
                      onChange={handleProfileChange}
                      className={`form-input pl-10 ${profileErrors.address ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                  </div>
                  {profileErrors.address && <p className="form-error">{profileErrors.address}</p>}
                </div>
                
                <div className="grid gap-6 md:grid-cols-3">
                  <div>
                    <label htmlFor="zipCode" className="form-label">CEP</label>
                    <div className="relative">
                      <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                        <MapPin size={16} className="text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="zipCode"
                        name="zipCode"
                        value={profileData.zipCode}
                        onChange={handleProfileChange}
                        className={`form-input pl-10 ${profileErrors.zipCode ? 'border-error-500 focus:ring-error-500' : ''}`}
                        maxLength={9}
                      />
                    </div>
                    {profileErrors.zipCode && <p className="form-error">{profileErrors.zipCode}</p>}
                  </div>
                  
                  <div>
                    <label htmlFor="city" className="form-label">Cidade</label>
                    <input
                      type="text"
                      id="city"
                      name="city"
                      value={profileData.city}
                      onChange={handleProfileChange}
                      className={`form-input ${profileErrors.city ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                    {profileErrors.city && <p className="form-error">{profileErrors.city}</p>}
                  </div>
                  
                  <div>
                    <label htmlFor="state" className="form-label">Estado</label>
                    <input
                      type="text"
                      id="state"
                      name="state"
                      value={profileData.state}
                      onChange={handleProfileChange}
                      className={`form-input ${profileErrors.state ? 'border-error-500 focus:ring-error-500' : ''}`}
                      maxLength={2}
                    />
                    {profileErrors.state && <p className="form-error">{profileErrors.state}</p>}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="btn-primary"
                  disabled={profileSubmitting}
                >
                  {profileSubmitting ? (
                    <span className="flex items-center">
                      <svg className="mr-2 h-4 w-4 animate-spin text-white" viewBox="0 0 24 24">
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Salvando...
                    </span>
                  ) : (
                    <>
                      <Save size={18} className="mr-2" />
                      Salvar Alterações
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
          
          {/* Change Password Form */}
          <div className="card">
            <h2 className="mb-6 text-xl font-semibold text-gray-900">
              Alterar Senha
            </h2>
            
            {passwordSuccess && (
              <div className="mb-6 rounded-md bg-success-50 p-3 text-success-700">
                <p>{passwordSuccess}</p>
              </div>
            )}
            
            <form onSubmit={handlePasswordSubmit}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="currentPassword" className="form-label">Senha Atual</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Lock size={16} className="text-gray-400" />
                    </div>
                    <input
                      type={showCurrentPassword ? 'text' : 'password'}
                      id="currentPassword"
                      name="currentPassword"
                      value={passwordData.currentPassword}
                      onChange={handlePasswordChange}
                      className={`form-input pl-10 pr-10 ${passwordErrors.currentPassword ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-500"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    >
                      {showCurrentPassword ? (
                        <EyeOff size={16} />
                      ) : (
                        <Eye size={16} />
                      )}
                    </button>
                  </div>
                  {passwordErrors.currentPassword && <p className="form-error">{passwordErrors.currentPassword}</p>}
                </div>
                
                <div>
                  <label htmlFor="newPassword" className="form-label">Nova Senha</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Lock size={16} className="text-gray-400" />
                    </div>
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      id="newPassword"
                      name="newPassword"
                      value={passwordData.newPassword}
                      onChange={handlePasswordChange}
                      className={`form-input pl-10 pr-10 ${passwordErrors.newPassword ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-500"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                    >
                      {showNewPassword ? (
                        <EyeOff size={16} />
                      ) : (
                        <Eye size={16} />
                      )}
                    </button>
                  </div>
                  {passwordErrors.newPassword && <p className="form-error">{passwordErrors.newPassword}</p>}
                </div>
                
                <div>
                  <label htmlFor="confirmPassword" className="form-label">Confirmar Nova Senha</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <Lock size={16} className="text-gray-400" />
                    </div>
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      id="confirmPassword"
                      name="confirmPassword"
                      value={passwordData.confirmPassword}
                      onChange={handlePasswordChange}
                      className={`form-input pl-10 pr-10 ${passwordErrors.confirmPassword ? 'border-error-500 focus:ring-error-500' : ''}`}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-500"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? (
                        <EyeOff size={16} />
                      ) : (
                        <Eye size={16} />
                      )}
                    </button>
                  </div>
                  {passwordErrors.confirmPassword && <p className="form-error">{passwordErrors.confirmPassword}</p>}
                </div>
              </div>
              
              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-start">
                  <AlertCircle size={16} className="mr-2 mt-0.5 text-gray-500" />
                  <p className="text-xs text-gray-500">
                    Use pelo menos 6 caracteres, incluindo letras, números e símbolos para uma senha segura.
                  </p>
                </div>
                
                <button
                  type="submit"
                  className="btn-primary"
                  disabled={passwordSubmitting}
                >
                  {passwordSubmitting ? (
                    <span className="flex items-center">
                      <svg className="mr-2 h-4 w-4 animate-spin text-white" viewBox="0 0 24 24">
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Alterando...
                    </span>
                  ) : (
                    'Alterar Senha'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientProfile;