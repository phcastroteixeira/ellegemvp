import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap, Mail, Lock, User, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { z } from 'zod';

const registerSchema = z.object({
  name: z.string().min(3, 'Nome deve ter no mínimo 3 caracteres'),
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'A senha deve ter no mínimo 6 caracteres'),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: 'As senhas não coincidem',
  path: ['confirmPassword'],
});

type RegisterFormData = z.infer<typeof registerSchema>;

const Register: React.FC = () => {
  const [formData, setFormData] = useState<RegisterFormData>({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState<Partial<RegisterFormData>>({});
  const [loading, setLoading] = useState(false);
  const [registerError, setRegisterError] = useState('');
  
  const navigate = useNavigate();
  const { login } = useAuthStore();

  const validateForm = (): boolean => {
    try {
      registerSchema.parse(formData);
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Partial<RegisterFormData> = {};
        error.errors.forEach((err) => {
          if (err.path[0] as keyof RegisterFormData) {
            newErrors[err.path[0] as keyof RegisterFormData] = err.message;
          }
        });
        setErrors(newErrors);
      }
      return false;
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError('');
    
    if (!validateForm()) return;
    
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Demo registration (in a real app, this would be an API call)
      login({ 
        id: Math.random().toString(36).substring(2, 11), 
        name: formData.name, 
        email: formData.email, 
        role: 'client' 
      });
      
      navigate('/');
    } catch (error) {
      setRegisterError('Ocorreu um erro ao criar a conta. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Left section with image/illustration */}
      <div className="hidden bg-primary-600 sm:block sm:w-1/2">
        <div className="flex h-full flex-col items-center justify-center p-8 text-white">
          <div className="mb-8 text-center">
            <h2 className="mb-3 text-3xl font-bold">Economize Energia</h2>
            <p className="text-primary-100">
              Gerencie seu consumo de forma inteligente e reduza seus custos
            </p>
          </div>
          
          <div className="max-w-md rounded-lg bg-white bg-opacity-10 p-6 shadow-lg backdrop-blur-sm">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 h-24 rounded bg-white bg-opacity-20"></div>
              <div className="h-24 rounded bg-white bg-opacity-20"></div>
              <div className="h-24 rounded bg-white bg-opacity-20"></div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right section with form */}
      <div className="flex w-full flex-col justify-center p-4 sm:w-1/2 md:p-8">
        <div className="mx-auto w-full max-w-md">
          <div className="mb-8 flex items-center">
            <img 
              src="/logo.png" 
              alt="Elle GE Solar" 
              className="h-10"
            />
          </div>
          
          <h2 className="mb-2 text-2xl font-bold text-gray-900">Crie sua conta</h2>
          <p className="mb-8 text-gray-600">Comece a gerenciar seu consumo de energia</p>
          
          {registerError && (
            <div className="mb-4 flex items-center rounded-md bg-error-50 p-3 text-error-700">
              <AlertCircle size={18} className="mr-2 flex-shrink-0" />
              <p>{registerError}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="name" className="form-label">Nome Completo</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <User size={16} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.name ? 'border-error-500 bg-error-50 focus:ring-error-500' : ''}`}
                  placeholder="Seu nome completo"
                />
              </div>
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>
            
            <div className="mb-4">
              <label htmlFor="email" className="form-label">Email</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Mail size={16} className="text-gray-400" />
                </div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.email ? 'border-error-500 bg-error-50 focus:ring-error-500' : ''}`}
                  placeholder="Seu email"
                />
              </div>
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>
            
            <div className="mb-4">
              <label htmlFor="password" className="form-label">Senha</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Lock size={16} className="text-gray-400" />
                </div>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.password ? 'border-error-500 bg-error-50 focus:ring-error-500' : ''}`}
                  placeholder="Crie uma senha"
                />
              </div>
              {errors.password && <p className="form-error">{errors.password}</p>}
            </div>
            
            <div className="mb-6">
              <label htmlFor="confirmPassword" className="form-label">Confirmar Senha</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Lock size={16} className="text-gray-400" />
                </div>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.confirmPassword ? 'border-error-500 bg-error-50 focus:ring-error-500' : ''}`}
                  placeholder="Confirme sua senha"
                />
              </div>
              {errors.confirmPassword && <p className="form-error">{errors.confirmPassword}</p>}
            </div>
            
            <button
              type="submit"
              className="btn-primary w-full"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="mr-2 h-4 w-4 animate-spin text-white" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Cadastrando...
                </span>
              ) : (
                'Cadastrar'
              )}
            </button>
          </form>
          
          <p className="mt-6 text-center text-sm text-gray-600">
            Já tem uma conta?{' '}
            <Link to="/login" className="font-medium text-primary-500 hover:text-primary-600">
              Faça login
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;