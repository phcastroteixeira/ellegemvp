import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Zap, Mail, Lock, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { z } from 'zod';

const loginSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'A senha deve ter no mínimo 6 caracteres'),
});

type LoginFormData = z.infer<typeof loginSchema>;

const Login: React.FC = () => {
  const [formData, setFormData] = useState<LoginFormData>({
    email: '',
    password: '',
  });
  const [errors, setErrors] = useState<Partial<LoginFormData>>({});
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState('');
  
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuthStore();

  // Get the redirect path from location state or default to home
  const from = (location.state as { from?: { pathname: string } })?.from?.pathname || '/';

  const validateForm = (): boolean => {
    try {
      loginSchema.parse(formData);
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Partial<LoginFormData> = {};
        error.errors.forEach((err) => {
          if (err.path[0] as keyof LoginFormData) {
            newErrors[err.path[0] as keyof LoginFormData] = err.message;
          }
        });
        setErrors(newErrors);
      }
      return false;
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    if (!validateForm()) return;
    
    setLoading(true);
    
    try {
      const success = login(formData);
      
      if (success) {
        // Redirect to the originally requested URL or default route
        navigate(from, { replace: true });
      } else {
        setLoginError('Email ou senha incorretos');
      }
    } catch (error) {
      setLoginError('Ocorreu um erro. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Left section with form */}
      <div className="flex w-full flex-col justify-center p-4 sm:w-1/2 md:p-8">
        <div className="mx-auto w-full max-w-md">
          <div className="mb-8 flex items-center">
            <img 
              src="/logo.png" 
              alt="Elle GE Solar" 
              className="h-10"
            />
          </div>
          
          <h2 className="mb-2 text-2xl font-bold text-gray-900">Bem-vindo de volta!</h2>
          <p className="mb-8 text-gray-600">Faça login para acessar sua conta</p>
          
          {loginError && (
            <div className="mb-4 flex items-center rounded-md bg-error-50 p-3 text-error-700">
              <AlertCircle size={18} className="mr-2 flex-shrink-0" />
              <p>{loginError}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="email" className="form-label">Email</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Mail size={16} className="text-gray-400" />
                </div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.email ? 'border-error-500 bg-error-50 focus:ring-error-500' : ''}`}
                  placeholder="Seu email"
                />
              </div>
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>
            
            <div className="mb-6">
              <label htmlFor="password" className="form-label">Senha</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Lock size={16} className="text-gray-400" />
                </div>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.password ? 'border-error-500 bg-error-50 focus:ring-error-500' : ''}`}
                  placeholder="Sua senha"
                />
              </div>
              {errors.password && <p className="form-error">{errors.password}</p>}
            </div>
            
            <button
              type="submit"
              className="btn-primary w-full"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="mr-2 h-4 w-4 animate-spin text-white" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Entrando...
                </span>
              ) : (
                'Entrar'
              )}
            </button>
          </form>
          
          <p className="mt-6 text-center text-sm text-gray-600">
            Não tem uma conta?{' '}
            <Link to="/register" className="font-medium text-primary-500 hover:text-primary-600">
              Cadastre-se
            </Link>
          </p>
          
          <div className="mt-8 text-center text-xs text-gray-500">
            <p>Para fins de demonstração, use:</p>
            <p>Admin: pedro@megalu.com.br / Mgu@2020</p>
            <p>Cliente: cliente@example.com / password</p>
          </div>
        </div>
      </div>
      
      {/* Right section with image/illustration */}
      <div className="hidden bg-primary-600 sm:block sm:w-1/2">
        <div className="flex h-full flex-col items-center justify-center p-8 text-white">
          <div className="mb-8 text-center">
            <h2 className="mb-3 text-3xl font-bold">Gerencie sua energia</h2>
            <p className="text-primary-100">
              Acompanhe seu consumo, faturas e economize energia
            </p>
          </div>
          
          <div className="max-w-md rounded-lg bg-white bg-opacity-10 p-6 shadow-lg backdrop-blur-sm">
            <div className="mb-4 space-y-2">
              <div className="h-2 w-2/3 rounded bg-white bg-opacity-30"></div>
              <div className="h-2 w-full rounded bg-white bg-opacity-30"></div>
              <div className="h-2 w-1/2 rounded bg-white bg-opacity-30"></div>
            </div>
            <div className="mt-6 flex justify-between space-x-4">
              <div className="h-16 w-1/3 rounded bg-white bg-opacity-20"></div>
              <div className="h-16 w-1/3 rounded bg-white bg-opacity-20"></div>
              <div className="h-16 w-1/3 rounded bg-white bg-opacity-20"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;