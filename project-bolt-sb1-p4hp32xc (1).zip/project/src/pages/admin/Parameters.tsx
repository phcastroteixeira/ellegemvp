import React, { useEffect, useState } from 'react';
import { 
  Plus, Trash2, Check, X, AlertCircle, Calendar, DollarSign, 
  Lightbulb, ChevronLeft, ChevronRight
} from 'lucide-react';
import { useParameterStore } from '../../stores/parameterStore';
import { MONTHS } from '../../types';
import Loader from '../../components/ui/Loader';
import { z } from 'zod';

const parameterSchema = z.object({
  month: z.number().min(1).max(12, 'Mês inválido'),
  year: z.number().min(2000).max(2100, 'Ano inválido'),
  utilityRate: z.number().min(0, 'Taxa da concessionária inválida'),
  publicLightingFee: z.number().min(0, 'Taxa de iluminação pública inválida'),
  saleValue: z.number().min(0, 'Valor de venda inválido'),
  minimumRate: z.number().min(0, 'Tarifa mínima inválida'),
});

type ParameterFormData = z.infer<typeof parameterSchema>;

const AdminParameters: React.FC = () => {
  const { parameters, fetchParameters, addParameter, updateParameter, deleteParameter, isLoading, error } = useParameterStore();
  
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<ParameterFormData>({
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    utilityRate: 0,
    publicLightingFee: 0,
    saleValue: 0,
    minimumRate: 0,
  });
  
  const [formErrors, setFormErrors] = useState<Partial<ParameterFormData>>({});
  const [formError, setFormError] = useState('');
  const [formSubmitting, setFormSubmitting] = useState(false);
  
  useEffect(() => {
    fetchParameters();
  }, [fetchParameters]);
  
  // Reset form
  const resetForm = () => {
    setFormData({
      month: new Date().getMonth() + 1,
      year: new Date().getFullYear(),
      utilityRate: 0,
      publicLightingFee: 0,
      saleValue: 0,
      minimumRate: 0,
    });
    setFormErrors({});
    setFormError('');
    setEditing(null);
  };
  
  // Toggle form visibility
  const toggleForm = () => {
    setShowForm(!showForm);
    if (!showForm) {
      resetForm();
    }
  };
  
  // Start editing parameter
  const handleEdit = (id: string) => {
    const parameter = parameters.find(p => p.id === id);
    if (parameter) {
      setFormData({
        month: parameter.month,
        year: parameter.year,
        utilityRate: parameter.utilityRate,
        publicLightingFee: parameter.publicLightingFee,
        saleValue: parameter.saleValue,
        minimumRate: parameter.minimumRate,
      });
      setEditing(id);
      setShowForm(true);
    }
  };
  
  // Format currency input
  const formatCurrency = (value: string) => {
    // Remove non-numeric characters
    const numbers = value.replace(/[^\d.]/g, '');
    
    // Ensure only one decimal point
    const parts = numbers.split('.');
    if (parts.length > 2) {
      parts.splice(2);
    }
    if (parts[1]?.length > 2) {
      parts[1] = parts[1].substring(0, 2);
    }
    
    return parts.join('.');
  };
  
  // Handle form input changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    
    // Convert string values to numbers for numeric fields
    const numericFields = ['month', 'year', 'utilityRate', 'publicLightingFee', 'saleValue', 'minimumRate'];
    let newValue: string | number = value;
    
    if (numericFields.includes(name)) {
      if (name === 'month' || name === 'year') {
        newValue = parseInt(value) || 0;
      } else {
        newValue = parseFloat(formatCurrency(value)) || 0;
      }
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: newValue,
    }));
  };
  
  // Validate form
  const validateForm = (): boolean => {
    try {
      parameterSchema.parse(formData);
      setFormErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Partial<ParameterFormData> = {};
        error.errors.forEach((err) => {
          if (err.path[0] as keyof ParameterFormData) {
            newErrors[err.path[0] as keyof ParameterFormData] = err.message;
          }
        });
        setFormErrors(newErrors);
      }
      return false;
    }
  };
  
  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    
    if (!validateForm()) return;
    
    // Check if parameter for this month/year already exists
    const existingParameter = parameters.find(
      p => p.month === formData.month && 
           p.year === formData.year && 
           (editing === null || p.id !== editing)
    );
    
    if (existingParameter) {
      setFormError(`Já existe um parâmetro para ${getMonthName(formData.month)}/${formData.year}`);
      return;
    }
    
    setFormSubmitting(true);
    
    try {
      if (editing) {
        await updateParameter(editing, formData);
      } else {
        await addParameter(formData);
      }
      
      setShowForm(false);
      resetForm();
    } catch (error) {
      setFormError('Ocorreu um erro ao salvar os parâmetros. Tente novamente.');
    } finally {
      setFormSubmitting(false);
    }
  };
  
  // Handle delete
  const handleDeleteClick = (parameterId: string) => {
    setDeleteConfirm(parameterId);
  };
  
  const handleConfirmDelete = async (parameterId: string) => {
    await deleteParameter(parameterId);
    setDeleteConfirm(null);
  };
  
  const handleCancelDelete = () => {
    setDeleteConfirm(null);
  };
  
  // Get month name
  const getMonthName = (month: number) => {
    return MONTHS.find(m => m.value === month)?.label || 'Mês inválido';
  };
  
  // Pagination
  const indexOfLastParameter = currentPage * itemsPerPage;
  const indexOfFirstParameter = indexOfLastParameter - itemsPerPage;
  
  // Sort parameters by year (desc) and month (desc)
  const sortedParameters = [...parameters].sort((a, b) => {
    if (a.year !== b.year) {
      return b.year - a.year; // Year descending
    }
    return b.month - a.month; // Month descending
  });
  
  const currentParameters = sortedParameters.slice(
    indexOfFirstParameter, 
    indexOfLastParameter
  );
  
  const totalPages = Math.ceil(parameters.length / itemsPerPage);

  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex flex-col justify-between sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Parâmetros</h1>
          <p className="text-gray-600">Defina os parâmetros para cálculo das faturas</p>
        </div>
        <button 
          onClick={toggleForm}
          className={`mt-4 flex items-center sm:mt-0 ${
            showForm ? 'btn-outline' : 'btn-primary'
          }`}
        >
          {showForm ? (
            'Cancelar'
          ) : (
            <>
              <Plus size={18} className="mr-2" />
              Novo Parâmetro
            </>
          )}
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="mb-8 rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-lg font-medium text-gray-900">
            {editing ? 'Editar Parâmetro' : 'Novo Parâmetro'}
          </h2>
          
          {formError && (
            <div className="mb-6 flex rounded-md bg-error-50 p-4 text-error-700">
              <AlertCircle size={20} className="mr-3 flex-shrink-0" />
              <p>{formError}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <label htmlFor="month" className="form-label">Mês</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Calendar size={16} className="text-gray-400" />
                  </div>
                  <select
                    id="month"
                    name="month"
                    value={formData.month}
                    onChange={handleChange}
                    className={`form-input pl-10 ${formErrors.month ? 'border-error-500 focus:ring-error-500' : ''}`}
                  >
                    {MONTHS.map(month => (
                      <option key={month.value} value={month.value}>
                        {month.label}
                      </option>
                    ))}
                  </select>
                </div>
                {formErrors.month && <p className="form-error">{formErrors.month}</p>}
              </div>
              
              <div>
                <label htmlFor="year" className="form-label">Ano</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Calendar size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    id="year"
                    name="year"
                    value={formData.year}
                    onChange={handleChange}
                    min={2000}
                    max={2100}
                    className={`form-input pl-10 ${formErrors.year ? 'border-error-500 focus:ring-error-500' : ''}`}
                  />
                </div>
                {formErrors.year && <p className="form-error">{formErrors.year}</p>}
              </div>
            </div>
            
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <div>
                <label htmlFor="utilityRate" className="form-label">Taxa da Concessionária (R$/kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    id="utilityRate"
                    name="utilityRate"
                    value={formData.utilityRate}
                    onChange={handleChange}
                    min={0}
                    step={0.000001}
                    className={`form-input pl-10 ${formErrors.utilityRate ? 'border-error-500 focus:ring-error-500' : ''}`}
                  />
                </div>
                {formErrors.utilityRate && <p className="form-error">{formErrors.utilityRate}</p>}
              </div>
              
              <div>
                <label htmlFor="publicLightingFee" className="form-label">Taxa de Iluminação Pública (R$)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Lightbulb size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    id="publicLightingFee"
                    name="publicLightingFee"
                    value={formData.publicLightingFee}
                    onChange={handleChange}
                    min={0}
                    step={0.01}
                    className={`form-input pl-10 ${formErrors.publicLightingFee ? 'border-error-500 focus:ring-error-500' : ''}`}
                  />
                </div>
                {formErrors.publicLightingFee && <p className="form-error">{formErrors.publicLightingFee}</p>}
              </div>
              
              <div>
                <label htmlFor="saleValue" className="form-label">Valor de Venda (R$/kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    id="saleValue"
                    name="saleValue"
                    value={formData.saleValue}
                    onChange={handleChange}
                    min={0}
                    step={0.01}
                    className={`form-input pl-10 ${formErrors.saleValue ? 'border-error-500 focus:ring-error-500' : ''}`}
                  />
                </div>
                {formErrors.saleValue && <p className="form-error">{formErrors.saleValue}</p>}
              </div>
              
              <div>
                <label htmlFor="minimumRate" className="form-label">Tarifa Mínima (R$)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    id="minimumRate"
                    name="minimumRate"
                    value={formData.minimumRate}
                    onChange={handleChange}
                    min={0}
                    step={0.01}
                    className={`form-input pl-10 ${formErrors.minimumRate ? 'border-error-500 focus:ring-error-500' : ''}`}
                  />
                </div>
                {formErrors.minimumRate && <p className="form-error">{formErrors.minimumRate}</p>}
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  resetForm();
                }}
                className="btn-outline"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="btn-primary"
                disabled={formSubmitting}
              >
                {formSubmitting ? (
                  <span className="flex items-center">
                    <svg className="mr-2 h-4 w-4 animate-spin text-white" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Salvando...
                  </span>
                ) : (
                  'Salvar Parâmetro'
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader label="Carregando parâmetros..." />
        </div>
      ) : error ? (
        <div className="rounded-md bg-error-50 p-4 text-error-700">
          <p>{error}</p>
        </div>
      ) : parameters.length === 0 ? (
        <div className="rounded-md bg-gray-50 p-8 text-center">
          <h3 className="mb-2 text-lg font-medium text-gray-700">Nenhum parâmetro encontrado</h3>
          <p className="text-gray-500">
            Defina os parâmetros para os períodos de faturamento
          </p>
        </div>
      ) : (
        <>
          <div className="table-container">
            <table className="table">
              <thead className="table-header">
                <tr>
                  <th className="table-header-cell">Período</th>
                  <th className="table-header-cell">Taxa da Concessionária</th>
                  <th className="table-header-cell">Taxa de Iluminação</th>
                  <th className="table-header-cell">Valor de Venda</th>
                  <th className="table-header-cell">Tarifa Mínima</th>
                  <th className="table-header-cell w-28">Ações</th>
                </tr>
              </thead>
              <tbody className="table-body">
                {currentParameters.map((parameter) => (
                  <tr key={parameter.id} className="table-row">
                    <td className="table-cell font-medium text-gray-900">
                      {getMonthName(parameter.month)}/{parameter.year}
                    </td>
                    <td className="table-cell">
                      R$ {parameter.utilityRate.toFixed(6)}/kWh
                    </td>
                    <td className="table-cell">
                      R$ {parameter.publicLightingFee.toFixed(2)}
                    </td>
                    <td className="table-cell">
                      R$ {parameter.saleValue.toFixed(2)}/kWh
                    </td>
                    <td className="table-cell">
                      R$ {parameter.minimumRate.toFixed(2)}
                    </td>
                    <td className="table-cell">
                      <div className="flex items-center space-x-3">
                        {deleteConfirm === parameter.id ? (
                          <>
                            <button
                              onClick={() => handleConfirmDelete(parameter.id)}
                              className="rounded-full bg-error-50 p-1.5 text-error-700 transition-colors hover:bg-error-100"
                              title="Confirmar exclusão"
                            >
                              <Check size={16} />
                            </button>
                            <button
                              onClick={handleCancelDelete}
                              className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                              title="Cancelar"
                            >
                              <X size={16} />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => handleEdit(parameter.id)}
                              className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                              title="Editar"
                            >
                              <svg 
                                xmlns="http://www.w3.org/2000/svg" 
                                width="16" 
                                height="16" 
                                viewBox="0 0 24 24" 
                                fill="none" 
                                stroke="currentColor" 
                                strokeWidth="2" 
                                strokeLinecap="round" 
                                strokeLinejoin="round"
                              >
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                              </svg>
                            </button>
                            <button
                              onClick={() => handleDeleteClick(parameter.id)}
                              className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                              title="Excluir"
                            >
                              <Trash2 size={16} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-6 flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Mostrando {indexOfFirstParameter + 1} a {Math.min(indexOfLastParameter, parameters.length)} de {parameters.length} parâmetros
              </div>
              <div className="flex space-x-1">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`rounded-md p-2 ${
                    currentPage === 1
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronLeft size={18} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i + 1}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`rounded-md px-3 py-1 ${
                      currentPage === i + 1
                        ? 'bg-primary-50 text-primary-600 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className={`rounded-md p-2 ${
                    currentPage === totalPages
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AdminParameters;