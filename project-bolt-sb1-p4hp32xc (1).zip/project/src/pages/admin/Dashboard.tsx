import React, { useEffect, useState } from 'react';
import { 
  Users, FileText, Zap, TrendingUp, Bolt, CreditCard, 
  BarChart, DollarSign
} from 'lucide-react';
import { useBillStore } from '../../stores/billStore';
import { useCustomerStore } from '../../stores/customerStore';
import StatsCard from '../../components/ui/StatsCard';
import DataChart from '../../components/ui/DataChart';
import Loader from '../../components/ui/Loader';
import { MONTHS } from '../../types';

const AdminDashboard: React.FC = () => {
  const { bills, fetchBills } = useBillStore();
  const { customers, fetchCustomers } = useCustomerStore();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await Promise.all([fetchBills(), fetchCustomers()]);
      setIsLoading(false);
    };
    
    loadData();
  }, [fetchBills, fetchCustomers]);

  // Calculate statistics and chart data
  const totalCustomers = customers.length;
  const totalBills = bills.length;
  const pendingBills = bills.filter(bill => bill.status === 'pending').length;
  const overdueBills = bills.filter(bill => bill.status === 'overdue').length;
  
  const totalRevenue = bills
    .filter(bill => bill.status === 'paid')
    .reduce((sum, bill) => sum + bill.totalAmount, 0);
  
  const averageConsumption = bills.length > 0
    ? bills.reduce((sum, bill) => sum + bill.energyConsumption, 0) / bills.length
    : 0;
  
  // Get consumption by month for chart
  const currentYear = new Date().getFullYear();
  const consumptionByMonth = Array(12).fill(0);
  
  bills.forEach(bill => {
    if (bill.year === currentYear) {
      consumptionByMonth[bill.month - 1] += bill.energyConsumption;
    }
  });
  
  const chartData = MONTHS.map((month, index) => ({
    label: month.label.substring(0, 3),
    value: consumptionByMonth[index]
  }));
  
  // Revenue by month for chart
  const revenueByMonth = Array(12).fill(0);
  
  bills.forEach(bill => {
    if (bill.year === currentYear && bill.status === 'paid') {
      revenueByMonth[bill.month - 1] += bill.totalAmount;
    }
  });
  
  const revenueData = MONTHS.map((month, index) => ({
    label: month.label.substring(0, 3),
    value: revenueByMonth[index]
  }));

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader size="large" label="Carregando dados do dashboard..." />
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Visão geral do sistema de gerenciamento de energia</p>
      </div>
      
      {/* Stats cards */}
      <div className="mb-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard 
          title="Total de Clientes" 
          value={totalCustomers} 
          icon={<Users />} 
          borderColor="border-primary-500"
        />
        <StatsCard 
          title="Faturas Pendentes" 
          value={pendingBills} 
          icon={<FileText />} 
          borderColor="border-warning-500"
        />
        <StatsCard 
          title="Faturas Atrasadas" 
          value={overdueBills} 
          icon={<CreditCard />} 
          borderColor="border-error-500"
        />
        <StatsCard 
          title="Receita Total" 
          value={`R$ ${totalRevenue.toFixed(2)}`} 
          icon={<DollarSign />} 
          borderColor="border-success-500"
          change={{ value: 12, type: 'increase' }}
        />
      </div>
      
      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="card">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Consumo por Mês</h2>
          <DataChart 
            data={chartData} 
            title="Consumo (kWh)" 
            barColor="#0F4C81"
          />
        </div>
        
        <div className="card">
          <h2 className="mb-4 text-lg font-semibold text-gray-900">Receita por Mês</h2>
          <DataChart 
            data={revenueData} 
            title="Receita (R$)" 
            barColor="#2CA58D"
          />
        </div>
      </div>
      
      {/* Insights row */}
      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <div className="card bg-primary-50">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary-100">
            <Zap size={24} className="text-primary-500" />
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">Consumo Médio</h3>
          <p className="text-gray-700">{averageConsumption.toFixed(2)} kWh por cliente</p>
        </div>
        
        <div className="card bg-secondary-50">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-secondary-100">
            <TrendingUp size={24} className="text-secondary-500" />
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">Taxa de Pagamento</h3>
          <p className="text-gray-700">
            {totalBills > 0 
              ? Math.round((bills.filter(b => b.status === 'paid').length / totalBills) * 100) 
              : 0}% das faturas pagas
          </p>
        </div>
        
        <div className="card bg-accent-50">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-accent-100">
            <Bolt size={24} className="text-accent-400" />
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">Eficiência Energética</h3>
          <p className="text-gray-700">12% de melhoria desde o mês passado</p>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;