import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Save, ArrowLeft, Calendar, User, Calculator,
  Bolt, DollarSign, CreditCard, AlertCircle
} from 'lucide-react';
import { useBillStore } from '../../stores/billStore';
import { useCustomerStore } from '../../stores/customerStore';
import { useParameterStore } from '../../stores/parameterStore';
import { MONTHS } from '../../types';
import Loader from '../../components/ui/Loader';

const billSchema = z.object({
  month: z.number().min(1).max(12, 'Mês inválido'),
  year: z.number().min(2000).max(2100, 'Ano inválido'),
  customerId: z.string().min(1, 'Cliente é obrigatório'),
  autoConsumption: z.number().min(0, 'Consumo próprio inválido'),
  receivedCredit: z.number().min(0, 'Crédito recebido inválido'),
  totalReading: z.number().min(0, 'Leitura total inválida'),
  utilityRate: z.number().min(0, 'Taxa da concessionária inválida'),
  saleValue: z.number().min(0, 'Valor de venda inválido'),
  accumulatedCredit: z.number().min(0, 'Crédito acumulado inválido'),
  totalValue: z.number().min(0, 'Valor total inválido'),
  accumulatedValue: z.number().min(0, 'Valor acumulado inválido'),
  publicLightingFee: z.number().min(0, 'Taxa de iluminação pública inválida'),
  minimumRate: z.number().min(0, 'Taxa mínima inválida'),
  issueDate: z.string().min(1, 'Data de emissão é obrigatória'),
  dueDate: z.string().min(1, 'Data de vencimento é obrigatória'),
  status: z.enum(['pending', 'paid', 'overdue']),
});

type BillFormData = z.infer<typeof billSchema>;

const AdminBillForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEditing = !!id;
  const navigate = useNavigate();
  const { getBill, addBill, updateBill, isLoading: billLoading } = useBillStore();
  const { customers, fetchCustomers, isLoading: customersLoading } = useCustomerStore();
  const { parameters, fetchParameters, isLoading: parametersLoading } = useParameterStore();
  const [parameterError, setParameterError] = React.useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    control,
    watch,
  } = useForm<BillFormData>({
    resolver: zodResolver(billSchema),
    defaultValues: {
      month: new Date().getMonth() + 1,
      year: new Date().getFullYear(),
      status: 'pending',
      autoConsumption: 0,
      receivedCredit: 0,
      totalReading: 0,
      utilityRate: 0,
      saleValue: 0,
      accumulatedCredit: 0,
      totalValue: 0,
      accumulatedValue: 0,
      publicLightingFee: 0,
      minimumRate: 0,
    }
  });

  // Watch values for calculations and parameter loading
  const month = useWatch({ control, name: 'month' });
  const year = useWatch({ control, name: 'year' });
  const autoConsumption = useWatch({ control, name: 'autoConsumption' });
  const receivedCredit = useWatch({ control, name: 'receivedCredit' });
  const saleValue = useWatch({ control, name: 'saleValue' });
  const minimumRate = useWatch({ control, name: 'minimumRate' });
  const publicLightingFee = useWatch({ control, name: 'publicLightingFee' });

  // Load parameters when month/year changes
  React.useEffect(() => {
    if (month && year && !isEditing) {
      const parameter = parameters.find(p => p.month === month && p.year === year);
      
      if (parameter) {
        setValue('utilityRate', parameter.utilityRate);
        setValue('publicLightingFee', parameter.publicLightingFee);
        setValue('saleValue', parameter.saleValue);
        setValue('minimumRate', parameter.minimumRate);
        setParameterError(null);
      } else {
        setParameterError(`Não existem parâmetros cadastrados para ${MONTHS.find(m => m.value === month)?.label}/${year}`);
      }
    }
  }, [month, year, parameters, setValue, isEditing]);

  // Update totalReading and totalValue whenever consumption or rates change
  React.useEffect(() => {
    // Update total reading
    const total = (autoConsumption || 0) + (receivedCredit || 0);
    setValue('totalReading', total);
    
    // Calculate total value using the new formula
    const baseValue = total * (saleValue || 0);
    const totalValue = baseValue + (minimumRate || 0) + (publicLightingFee || 0);
    setValue('totalValue', totalValue);
  }, [autoConsumption, receivedCredit, saleValue, minimumRate, publicLightingFee, setValue]);

  const isLoading = billLoading || customersLoading || parametersLoading;

  React.useEffect(() => {
    fetchCustomers();
    fetchParameters();
    
    if (isEditing && id) {
      const bill = getBill(id);
      if (bill) {
        Object.entries(bill).forEach(([key, value]) => {
          setValue(key as keyof BillFormData, value);
        });
      }
    }
  }, [isEditing, id, getBill, fetchCustomers, fetchParameters, setValue]);

  const onSubmit = async (data: BillFormData) => {
    try {
      if (isEditing && id) {
        await updateBill(id, data);
      } else {
        await addBill(data);
      }
      navigate('/admin/bills');
    } catch (error) {
      console.error('Failed to save bill:', error);
    }
  };

  if (isLoading && isEditing) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader label="Carregando dados da fatura..." />
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <button
            onClick={() => navigate('/admin/bills')}
            className="mb-2 flex items-center text-gray-600 hover:text-primary-600"
          >
            <ArrowLeft size={16} className="mr-1" />
            Voltar para a lista
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isEditing ? 'Editar Fatura' : 'Nova Fatura'}
          </h1>
        </div>
      </div>

      <div className="card">
        {parameterError && (
          <div className="mb-6 flex items-center rounded-md bg-warning-50 p-4 text-warning-700">
            <AlertCircle size={20} className="mr-3 flex-shrink-0" />
            <p>{parameterError}</p>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Período de Referência */}
          <div>
            <h3 className="mb-4 text-lg font-medium text-gray-900">Período de Referência</h3>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <label className="form-label">Mês</label>
                <select
                  {...register('month', { valueAsNumber: true })}
                  className="form-input"
                >
                  {MONTHS.map(month => (
                    <option key={month.value} value={month.value}>
                      {month.label}
                    </option>
                  ))}
                </select>
                {errors.month && (
                  <p className="form-error">{errors.month.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Ano</label>
                <input
                  type="number"
                  min={2000}
                  max={2100}
                  {...register('year', { valueAsNumber: true })}
                  className="form-input"
                />
                {errors.year && (
                  <p className="form-error">{errors.year.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Cliente e Datas */}
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <label className="form-label">Cliente</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <User size={16} className="text-gray-400" />
                </div>
                <select
                  {...register('customerId')}
                  className="form-input pl-10"
                >
                  <option value="">Selecione um cliente</option>
                  {customers.map(customer => (
                    <option key={customer.id} value={customer.id}>
                      {customer.name} - UC: {customer.consumerUnit}
                    </option>
                  ))}
                </select>
              </div>
              {errors.customerId && (
                <p className="form-error">{errors.customerId.message}</p>
              )}
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="form-label">Data de Emissão</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Calendar size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="date"
                    {...register('issueDate')}
                    className="form-input pl-10"
                  />
                </div>
                {errors.issueDate && (
                  <p className="form-error">{errors.issueDate.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Data de Vencimento</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Calendar size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="date"
                    {...register('dueDate')}
                    className="form-input pl-10"
                  />
                </div>
                {errors.dueDate && (
                  <p className="form-error">{errors.dueDate.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Consumo */}
          <div>
            <h3 className="mb-4 text-lg font-medium text-gray-900">Consumo</h3>
            <div className="grid gap-6 md:grid-cols-3">
              <div>
                <label className="form-label">Consumo Próprio (kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Bolt size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('autoConsumption', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.autoConsumption && (
                  <p className="form-error">{errors.autoConsumption.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Crédito Recebido (kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Bolt size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('receivedCredit', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.receivedCredit && (
                  <p className="form-error">{errors.receivedCredit.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Leitura Total (kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Calculator size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    {...register('totalReading', { valueAsNumber: true })}
                    className="form-input pl-10 bg-gray-50"
                    readOnly
                  />
                </div>
                {errors.totalReading && (
                  <p className="form-error">{errors.totalReading.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Valores */}
          <div>
            <h3 className="mb-4 text-lg font-medium text-gray-900">Valores</h3>
            <div className="grid gap-6 md:grid-cols-3">
              <div>
                <label className="form-label">Taxa da Concessionária (R$/kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.000001"
                    {...register('utilityRate', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.utilityRate && (
                  <p className="form-error">{errors.utilityRate.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Valor de Venda (R$/kWh)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('saleValue', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.saleValue && (
                  <p className="form-error">{errors.saleValue.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Taxa Mínima (R$)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('minimumRate', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.minimumRate && (
                  <p className="form-error">{errors.minimumRate.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Taxa de Iluminação Pública (R$)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('publicLightingFee', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.publicLightingFee && (
                  <p className="form-error">{errors.publicLightingFee.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Valor Total (R$)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <CreditCard size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('totalValue', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10 bg-gray-50"
                    readOnly
                  />
                </div>
                {errors.totalValue && (
                  <p className="form-error">{errors.totalValue.message}</p>
                )}
              </div>

              <div>
                <label className="form-label">Valor Acumulado (R$)</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <DollarSign size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register('accumulatedValue', { 
                      valueAsNumber: true,
                      min: 0
                    })}
                    className="form-input pl-10"
                  />
                </div>
                {errors.accumulatedValue && (
                  <p className="form-error">{errors.accumulatedValue.message}</p>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/admin/bills')}
              className="btn-outline"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="btn-primary"
            >
              <Save size={18} className="mr-2" />
              {isEditing ? 'Salvar Alterações' : 'Criar Fatura'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminBillForm;