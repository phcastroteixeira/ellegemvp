import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  Save, ArrowLeft, AlertCircle, User, Mail, Phone, Home,
  MapPin, AtSign, Map 
} from 'lucide-react';
import { useCustomerStore } from '../../stores/customerStore';
import { STATES } from '../../types';
import { z } from 'zod';
import Loader from '../../components/ui/Loader';

const customerSchema = z.object({
  name: z.string().min(3, 'Nome deve ter pelo menos 3 caracteres'),
  email: z.string().email('Email inválido'),
  phone: z.string().min(10, 'Telefone inválido'),
  consumerUnit: z.string().min(5, 'Unidade consumidora inválida'),
  address: z.string().min(5, 'Endereço deve ter pelo menos 5 caracteres'),
  zipCode: z.string().regex(/^\d{5}-?\d{3}$/, 'CEP inválido'),
  city: z.string().min(3, 'Cidade deve ter pelo menos 3 caracteres'),
  state: z.string().length(2, 'Estado inválido'),
});

type CustomerFormData = z.infer<typeof customerSchema>;

const AdminCustomerForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEditing = !!id;
  const navigate = useNavigate();
  const { getCustomer, addCustomer, updateCustomer, isLoading, error } = useCustomerStore();
  
  const [formData, setFormData] = useState<CustomerFormData>({
    name: '',
    email: '',
    phone: '',
    consumerUnit: '',
    address: '',
    zipCode: '',
    city: '',
    state: '',
  });
  
  const [errors, setErrors] = useState<Partial<CustomerFormData>>({});
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  
  useEffect(() => {
    if (isEditing) {
      const customer = getCustomer(id);
      if (customer) {
        setFormData({
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
          consumerUnit: customer.consumerUnit,
          address: customer.address,
          zipCode: customer.zipCode,
          city: customer.city,
          state: customer.state,
        });
      }
    }
  }, [isEditing, id, getCustomer]);
  
  const validateForm = (): boolean => {
    try {
      customerSchema.parse(formData);
      setErrors({});
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: Partial<CustomerFormData> = {};
        error.errors.forEach((err) => {
          if (err.path[0] as keyof CustomerFormData) {
            newErrors[err.path[0] as keyof CustomerFormData] = err.message;
          }
        });
        setErrors(newErrors);
      }
      return false;
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const formatPhoneNumber = (value: string) => {
    // Remove non-numeric characters
    const numbers = value.replace(/\D/g, '');
    
    // Format as (XX) XXXXX-XXXX
    if (numbers.length <= 2) {
      return numbers;
    } else if (numbers.length <= 7) {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    } else {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
    }
  };
  
  const formatZipCode = (value: string) => {
    // Remove non-numeric characters
    const numbers = value.replace(/\D/g, '');
    
    // Format as XXXXX-XXX
    if (numbers.length <= 5) {
      return numbers;
    } else {
      return `${numbers.slice(0, 5)}-${numbers.slice(5, 8)}`;
    }
  };
  
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatPhoneNumber(e.target.value);
    setFormData((prev) => ({ ...prev, phone: formattedValue }));
  };
  
  const handleZipCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatZipCode(e.target.value);
    setFormData((prev) => ({ ...prev, zipCode: formattedValue }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    
    if (!validateForm()) return;
    
    setFormSubmitting(true);
    
    try {
      if (isEditing && id) {
        await updateCustomer(id, formData);
      } else {
        await addCustomer(formData);
      }
      navigate('/admin/customers');
    } catch (error) {
      setFormError('Ocorreu um erro ao salvar o cliente. Tente novamente.');
    } finally {
      setFormSubmitting(false);
    }
  };

  if (isLoading && isEditing) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader label="Carregando dados do cliente..." />
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <button
            onClick={() => navigate('/admin/customers')}
            className="mb-2 flex items-center text-gray-600 hover:text-primary-600"
          >
            <ArrowLeft size={16} className="mr-1" />
            Voltar para a lista
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isEditing ? 'Editar Cliente' : 'Novo Cliente'}
          </h1>
        </div>
      </div>
      
      <div className="card">
        {formError && (
          <div className="mb-6 flex rounded-md bg-error-50 p-4 text-error-700">
            <AlertCircle size={20} className="mr-3 flex-shrink-0" />
            <p>{formError}</p>
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6 grid gap-6 md:grid-cols-2">
            <div>
              <label htmlFor="name" className="form-label">Nome Completo</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <User size={16} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.name ? 'border-error-500 focus:ring-error-500' : ''}`}
                  placeholder="Nome do cliente"
                />
              </div>
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>
            
            <div>
              <label htmlFor="email" className="form-label">Email</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Mail size={16} className="text-gray-400" />
                </div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.email ? 'border-error-500 focus:ring-error-500' : ''}`}
                  placeholder="Email do cliente"
                />
              </div>
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>
            
            <div>
              <label htmlFor="phone" className="form-label">Telefone</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Phone size={16} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handlePhoneChange}
                  className={`form-input pl-10 ${errors.phone ? 'border-error-500 focus:ring-error-500' : ''}`}
                  placeholder="(XX) XXXXX-XXXX"
                  maxLength={15}
                />
              </div>
              {errors.phone && <p className="form-error">{errors.phone}</p>}
            </div>
            
            <div>
              <label htmlFor="consumerUnit" className="form-label">Unidade Consumidora</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <AtSign size={16} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  id="consumerUnit"
                  name="consumerUnit"
                  value={formData.consumerUnit}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.consumerUnit ? 'border-error-500 focus:ring-error-500' : ''}`}
                  placeholder="Número da unidade consumidora"
                />
              </div>
              {errors.consumerUnit && <p className="form-error">{errors.consumerUnit}</p>}
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="mb-3 text-lg font-medium text-gray-900">Endereço</h3>
            
            <div className="mb-4">
              <label htmlFor="address" className="form-label">Logradouro</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <Home size={16} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className={`form-input pl-10 ${errors.address ? 'border-error-500 focus:ring-error-500' : ''}`}
                  placeholder="Rua, número, complemento"
                />
              </div>
              {errors.address && <p className="form-error">{errors.address}</p>}
            </div>
            
            <div className="grid gap-6 md:grid-cols-3">
              <div>
                <label htmlFor="zipCode" className="form-label">CEP</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <MapPin size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="zipCode"
                    name="zipCode"
                    value={formData.zipCode}
                    onChange={handleZipCodeChange}
                    className={`form-input pl-10 ${errors.zipCode ? 'border-error-500 focus:ring-error-500' : ''}`}
                    placeholder="XXXXX-XXX"
                    maxLength={9}
                  />
                </div>
                {errors.zipCode && <p className="form-error">{errors.zipCode}</p>}
              </div>
              
              <div>
                <label htmlFor="city" className="form-label">Cidade</label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <Map size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    className={`form-input pl-10 ${errors.city ? 'border-error-500 focus:ring-error-500' : ''}`}
                    placeholder="Nome da cidade"
                  />
                </div>
                {errors.city && <p className="form-error">{errors.city}</p>}
              </div>
              
              <div>
                <label htmlFor="state" className="form-label">Estado</label>
                <select
                  id="state"
                  name="state"
                  value={formData.state}
                  onChange={handleChange}
                  className={`form-input ${errors.state ? 'border-error-500 focus:ring-error-500' : ''}`}
                >
                  <option value="">Selecione o estado</option>
                  {STATES.map((state) => (
                    <option key={state.value} value={state.value}>
                      {state.label} ({state.value})
                    </option>
                  ))}
                </select>
                {errors.state && <p className="form-error">{errors.state}</p>}
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/admin/customers')}
              className="btn-outline"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={formSubmitting}
            >
              {formSubmitting ? (
                <span className="flex items-center">
                  <svg className="mr-2 h-4 w-4 animate-spin text-white" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Salvando...
                </span>
              ) : (
                <>
                  <Save size={18} className="mr-2" />
                  Salvar Cliente
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminCustomerForm;