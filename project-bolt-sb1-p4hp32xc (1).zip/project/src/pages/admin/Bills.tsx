import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Plus, Search, Edit, Trash2, ChevronLeft, ChevronRight,
  Check, X, Download, FileText, Database
} from 'lucide-react';
import { useBillStore } from '../../stores/billStore';
import { useCustomerStore } from '../../stores/customerStore';
import Loader from '../../components/ui/Loader';
import { Bill, MONTHS } from '../../types';
import { format } from 'date-fns';

const AdminBills: React.FC = () => {
  const { bills, fetchBills, deleteBill, isLoading, error } = useBillStore();
  const { customers, fetchCustomers } = useCustomerStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const filterCustomerId = queryParams.get('customerId');

  useEffect(() => {
    fetchBills();
    fetchCustomers();
  }, [fetchBills, fetchCustomers]);

  // Get customer name by ID
  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.name : 'Cliente não encontrado';
  };

  // Get month name
  const getMonthName = (month: number) => {
    return MONTHS.find(m => m.value === month)?.label || 'Mês inválido';
  };

  // Format status
  const formatStatus = (status: string) => {
    switch (status) {
      case 'pending':
        return { label: 'Pendente', class: 'badge-warning' };
      case 'paid':
        return { label: 'Pago', class: 'badge-success' };
      case 'overdue':
        return { label: 'Atrasado', class: 'badge-error' };
      default:
        return { label: status, class: '' };
    }
  };

  // Filter bills based on search term and customerId
  const filteredBills = bills.filter(bill => {
    // First filter by customerId if provided
    if (filterCustomerId && bill.customerId !== filterCustomerId) {
      return false;
    }
    
    // Then filter by search term
    const customerName = getCustomerName(bill.customerId).toLowerCase();
    const monthYear = `${getMonthName(bill.month)} ${bill.year}`.toLowerCase();
    
    return (
      customerName.includes(searchTerm.toLowerCase()) ||
      monthYear.includes(searchTerm.toLowerCase()) ||
      bill.consumerUnit?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (bill.totalAmount ?? 0).toString().includes(searchTerm)
    );
  });

  // Pagination
  const indexOfLastBill = currentPage * itemsPerPage;
  const indexOfFirstBill = indexOfLastBill - itemsPerPage;
  const currentBills = filteredBills.slice(indexOfFirstBill, indexOfLastBill);
  const totalPages = Math.ceil(filteredBills.length / itemsPerPage);

  const handleDeleteClick = (billId: string) => {
    setDeleteConfirm(billId);
  };

  const handleConfirmDelete = async (billId: string) => {
    await deleteBill(billId);
    setDeleteConfirm(null);
  };

  const handleCancelDelete = () => {
    setDeleteConfirm(null);
  };

  const getPageTitle = () => {
    if (filterCustomerId) {
      const customerName = getCustomerName(filterCustomerId);
      return `Faturas de ${customerName}`;
    }
    return 'Faturas';
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex flex-col justify-between sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{getPageTitle()}</h1>
          <div className="mt-2 flex items-center text-gray-600">
            <Database size={16} className="mr-2" />
            <span>Total de registros: <strong>{bills.length}</strong></span>
          </div>
        </div>
        <Link 
          to="/admin/bills/new"
          className="btn-primary mt-4 flex items-center sm:mt-0"
        >
          <Plus size={18} className="mr-2" />
          Nova Fatura
        </Link>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="form-input pl-10"
            placeholder="Buscar por cliente, período ou valor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader label="Carregando faturas..." />
        </div>
      ) : error ? (
        <div className="rounded-md bg-error-50 p-4 text-error-700">
          <p>{error}</p>
        </div>
      ) : filteredBills.length === 0 ? (
        <div className="rounded-md bg-gray-50 p-8 text-center">
          <h3 className="mb-2 text-lg font-medium text-gray-700">Nenhuma fatura encontrada</h3>
          <p className="text-gray-500">
            {filterCustomerId 
              ? 'Este cliente ainda não possui faturas registradas'
              : searchTerm 
                ? 'Tente ajustar os termos de busca'
                : 'Comece adicionando uma nova fatura'
            }
          </p>
        </div>
      ) : (
        <>
          <div className="table-container">
            <table className="table">
              <thead className="table-header">
                <tr>
                  <th className="table-header-cell">Cliente</th>
                  <th className="table-header-cell">Período</th>
                  <th className="table-header-cell">Consumo</th>
                  <th className="table-header-cell">Valor</th>
                  <th className="table-header-cell">Vencimento</th>
                  <th className="table-header-cell">Status</th>
                  <th className="table-header-cell">Ações</th>
                </tr>
              </thead>
              <tbody className="table-body">
                {currentBills.map((bill: Bill) => {
                  const status = formatStatus(bill.status);
                  
                  return (
                    <tr key={bill.id} className="table-row">
                      <td className="table-cell font-medium text-gray-900">
                        {getCustomerName(bill.customerId)}
                      </td>
                      <td className="table-cell">
                        {getMonthName(bill.month)}/{bill.year}
                      </td>
                      <td className="table-cell">
                        {bill.totalReading} kWh
                      </td>
                      <td className="table-cell font-medium">
                        R$ {(bill.receivedValue ?? 0).toFixed(2)}
                      </td>
                      <td className="table-cell">
                        {format(new Date(bill.dueDate), 'dd/MM/yyyy')}
                      </td>
                      <td className="table-cell">
                        <span className={status.class}>
                          {status.label}
                        </span>
                      </td>
                      <td className="table-cell">
                        <div className="flex items-center space-x-3">
                          {deleteConfirm === bill.id ? (
                            <>
                              <button
                                onClick={() => handleConfirmDelete(bill.id)}
                                className="rounded-full bg-error-50 p-1.5 text-error-700 transition-colors hover:bg-error-100"
                                title="Confirmar exclusão"
                              >
                                <Check size={16} />
                              </button>
                              <button
                                onClick={handleCancelDelete}
                                className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                                title="Cancelar"
                              >
                                <X size={16} />
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => alert('Funcionalidade em desenvolvimento')}
                                className="rounded-full bg-primary-50 p-1.5 text-primary-700 transition-colors hover:bg-primary-100"
                                title="Baixar fatura"
                              >
                                <Download size={16} />
                              </button>
                              <Link
                                to={`/admin/bills/${bill.id}`}
                                className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                                title="Editar"
                              >
                                <Edit size={16} />
                              </Link>
                              <button
                                onClick={() => handleDeleteClick(bill.id)}
                                className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                                title="Excluir"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-6 flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Mostrando {indexOfFirstBill + 1} a {Math.min(indexOfLastBill, filteredBills.length)} de {filteredBills.length} faturas
              </div>
              <div className="flex space-x-1">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`rounded-md p-2 ${
                    currentPage === 1
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronLeft size={18} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i + 1}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`rounded-md px-3 py-1 ${
                      currentPage === i + 1
                        ? 'bg-primary-50 text-primary-600 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className={`rounded-md p-2 ${
                    currentPage === totalPages
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AdminBills;