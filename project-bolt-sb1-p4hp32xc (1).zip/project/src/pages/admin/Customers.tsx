import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Plus, Search, Edit, Trash2, ChevronLeft, ChevronRight,
  Check, X, FileText
} from 'lucide-react';
import { useCustomerStore } from '../../stores/customerStore';
import { useBillStore } from '../../stores/billStore';
import Loader from '../../components/ui/Loader';
import { Customer } from '../../types';

const AdminCustomers: React.FC = () => {
  const { customers, fetchCustomers, deleteCustomer, isLoading, error } = useCustomerStore();
  const { bills, fetchBills } = useBillStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCustomers();
    fetchBills();
  }, [fetchCustomers, fetchBills]);

  // Filter customers based on search term
  const filteredCustomers = customers.filter(customer => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.consumerUnit.includes(searchTerm)
  );

  // Pagination
  const indexOfLastCustomer = currentPage * itemsPerPage;
  const indexOfFirstCustomer = indexOfLastCustomer - itemsPerPage;
  const currentCustomers = filteredCustomers.slice(indexOfFirstCustomer, indexOfLastCustomer);
  const totalPages = Math.ceil(filteredCustomers.length / itemsPerPage);

  // Check if customer has bills
  const customerHasBills = (customerId: string) => {
    return bills.some(bill => bill.customerId === customerId);
  };

  const handleDeleteClick = (customerId: string) => {
    setDeleteConfirm(customerId);
  };

  const handleConfirmDelete = async (customerId: string) => {
    if (customerHasBills(customerId)) {
      alert('Este cliente possui faturas associadas. Remova as faturas primeiro.');
      setDeleteConfirm(null);
      return;
    }
    
    await deleteCustomer(customerId);
    setDeleteConfirm(null);
  };

  const handleCancelDelete = () => {
    setDeleteConfirm(null);
  };

  const handleViewBills = (customerId: string) => {
    navigate(`/admin/bills?customerId=${customerId}`);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex flex-col justify-between sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Clientes</h1>
          <p className="text-gray-600">Gerencie os clientes do sistema</p>
        </div>
        <Link 
          to="/admin/customers/new"
          className="btn-primary mt-4 flex items-center sm:mt-0"
        >
          <Plus size={18} className="mr-2" />
          Novo Cliente
        </Link>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="form-input pl-10"
            placeholder="Buscar por nome, email ou unidade consumidora..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader label="Carregando clientes..." />
        </div>
      ) : error ? (
        <div className="rounded-md bg-error-50 p-4 text-error-700">
          <p>{error}</p>
        </div>
      ) : filteredCustomers.length === 0 ? (
        <div className="rounded-md bg-gray-50 p-8 text-center">
          <h3 className="mb-2 text-lg font-medium text-gray-700">Nenhum cliente encontrado</h3>
          <p className="text-gray-500">
            {searchTerm 
              ? 'Tente ajustar os termos de busca'
              : 'Comece adicionando um novo cliente'
            }
          </p>
        </div>
      ) : (
        <>
          <div className="table-container">
            <table className="table">
              <thead className="table-header">
                <tr>
                  <th className="table-header-cell">Nome</th>
                  <th className="table-header-cell">Unidade Consumidora</th>
                  <th className="table-header-cell hidden sm:table-cell">Email</th>
                  <th className="table-header-cell hidden md:table-cell">Telefone</th>
                  <th className="table-header-cell hidden lg:table-cell">Cidade/Estado</th>
                  <th className="table-header-cell">Ações</th>
                </tr>
              </thead>
              <tbody className="table-body">
                {currentCustomers.map((customer: Customer) => (
                  <tr key={customer.id} className="table-row">
                    <td className="table-cell font-medium text-gray-900">
                      {customer.name}
                    </td>
                    <td className="table-cell">
                      <span className="rounded-full bg-primary-50 px-2.5 py-0.5 text-xs font-medium text-primary-700">
                        {customer.consumerUnit}
                      </span>
                    </td>
                    <td className="table-cell hidden sm:table-cell">{customer.email}</td>
                    <td className="table-cell hidden md:table-cell">{customer.phone}</td>
                    <td className="table-cell hidden lg:table-cell">
                      {customer.city}/{customer.state}
                    </td>
                    <td className="table-cell">
                      <div className="flex items-center space-x-3">
                        {deleteConfirm === customer.id ? (
                          <>
                            <button
                              onClick={() => handleConfirmDelete(customer.id)}
                              className="rounded-full bg-error-50 p-1.5 text-error-700 transition-colors hover:bg-error-100"
                              title="Confirmar exclusão"
                            >
                              <Check size={16} />
                            </button>
                            <button
                              onClick={handleCancelDelete}
                              className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                              title="Cancelar"
                            >
                              <X size={16} />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => handleViewBills(customer.id)}
                              className="rounded-full bg-primary-50 p-1.5 text-primary-700 transition-colors hover:bg-primary-100"
                              title="Ver faturas"
                            >
                              <FileText size={16} />
                            </button>
                            <Link
                              to={`/admin/customers/${customer.id}`}
                              className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                              title="Editar"
                            >
                              <Edit size={16} />
                            </Link>
                            <button
                              onClick={() => handleDeleteClick(customer.id)}
                              className="rounded-full bg-gray-50 p-1.5 text-gray-700 transition-colors hover:bg-gray-100"
                              title="Excluir"
                            >
                              <Trash2 size={16} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-6 flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Mostrando {indexOfFirstCustomer + 1} a {Math.min(indexOfLastCustomer, filteredCustomers.length)} de {filteredCustomers.length} clientes
              </div>
              <div className="flex space-x-1">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`rounded-md p-2 ${
                    currentPage === 1
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronLeft size={18} />
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i + 1}
                    onClick={() => setCurrentPage(i + 1)}
                    className={`rounded-md px-3 py-1 ${
                      currentPage === i + 1
                        ? 'bg-primary-50 text-primary-600 font-medium'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className={`rounded-md p-2 ${
                    currentPage === totalPages
                      ? 'cursor-not-allowed text-gray-400'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AdminCustomers;