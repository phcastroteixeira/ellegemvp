import React from 'react';
import { Download } from 'lucide-react';
import { generateBillPDF } from '../services/pdfService';
import { Bill, Customer } from '../types';
import { useCustomerStore } from '../stores/customerStore';

interface BillPDFProps {
  bill: Bill;
}

const BillPDF: React.FC<BillPDFProps> = ({ bill }) => {
  const { getCustomer } = useCustomerStore();
  const [isGenerating, setIsGenerating] = React.useState(false);
  
  const handleDownload = async () => {
    try {
      setIsGenerating(true);
      
      const customer = getCustomer(bill.customerId);
      if (!customer) {
        throw new Error('Cliente não encontrado');
      }
      
      await generateBillPDF(bill, customer);
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      alert('Ocorreu um erro ao gerar o PDF. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <button
      onClick={handleDownload}
      disabled={isGenerating}
      className="btn-primary"
    >
      <Download size={18} className="mr-2" />
      {isGenerating ? 'Gerando PDF...' : 'Baixar PDF'}
    </button>
  );
};

export default BillPDF;