import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Home, FileText, User, Menu, X, LogOut, 
  Sun, Moon, AlertCircle
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

const ClientLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { logout, user } = useAuthStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navigationItems = [
    { name: 'Dashboard', path: '/', icon: <Home size={20} /> },
    { name: 'Minhas Faturas', path: '/bills', icon: <FileText size={20} /> },
    { name: 'Meu Perfil', path: '/profile', icon: <User size={20} /> },
  ];

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-20 bg-gray-800 bg-opacity-50 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 left-0 z-30 w-64 transform bg-white shadow-lg transition duration-300 ease-in-out lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b border-gray-200 px-6">
          <div className="flex items-center">
            <img 
              src="/logo.png" 
              alt="Elle GE Solar" 
              className="h-8"
            />
          </div>
          <button onClick={toggleSidebar} className="lg:hidden">
            <X size={24} />
          </button>
        </div>

        <div className="p-4">
          <div className="mb-6 flex items-center rounded-lg bg-gray-50 p-3">
            <div className="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-primary-100">
              <User size={20} className="text-primary-500" />
            </div>
            <div>
              <p className="text-sm font-medium">{user?.name || 'Cliente'}</p>
              <p className="text-xs text-gray-500">{user?.email || ''}</p>
            </div>
          </div>
        </div>

        <nav className="px-4">
          <ul className="space-y-2">
            {navigationItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center rounded-lg px-4 py-3 transition-colors ${
                    location.pathname === item.path
                      ? 'bg-primary-500 text-white'
                      : 'text-gray-700 hover:bg-primary-50 hover:text-primary-500'
                  }`}
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </Link>
              </li>
            ))}
          </ul>

          <div className="mt-10 border-t border-gray-200 pt-6">
            <button
              onClick={handleLogout}
              className="flex w-full items-center rounded-lg px-4 py-3 text-gray-700 transition-colors hover:bg-primary-50 hover:text-primary-500"
            >
              <LogOut size={20} />
              <span className="ml-3">Sair</span>
            </button>
            
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="mt-2 flex w-full items-center rounded-lg px-4 py-3 text-gray-700 transition-colors hover:bg-primary-50 hover:text-primary-500"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
              <span className="ml-3">{darkMode ? 'Modo Claro' : 'Modo Escuro'}</span>
            </button>
          </div>
        </nav>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-white shadow">
          <div className="flex h-16 items-center justify-between px-4 lg:px-6">
            <button
              onClick={toggleSidebar}
              className="rounded-lg p-2 text-gray-700 hover:bg-gray-100 lg:hidden"
            >
              <Menu size={24} />
            </button>
            
            <div className="flex items-center">
              <div className="mr-2 flex space-x-1">
                <AlertCircle size={18} className="text-primary-500" />
              </div>
              <span className="hidden text-sm text-gray-700 md:block">Suporte: (11) 9999-9999</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 lg:p-8">
          <Outlet />
        </main>

        {/* Footer */}
        <footer className="border-t border-gray-200 bg-white p-4 text-center text-sm text-gray-500">
          <p>© 2025 Elle GE Solar - Todos os direitos reservados</p>
        </footer>
      </div>
    </div>
  );
};

export default ClientLayout;