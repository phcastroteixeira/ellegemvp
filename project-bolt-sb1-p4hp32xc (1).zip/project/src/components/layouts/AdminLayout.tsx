import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Home, Users, FileText, Settings, Menu, X, LogOut, 
  Sun, Moon, BarChart
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';

const AdminLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navigationItems = [
    { name: 'Dashboard', path: '/admin', icon: <Home size={20} /> },
    { name: 'Clientes', path: '/admin/customers', icon: <Users size={20} /> },
    { name: 'Faturas', path: '/admin/bills', icon: <FileText size={20} /> },
    { name: 'Parâmetros', path: '/admin/parameters', icon: <BarChart size={20} /> },
  ];

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-20 bg-gray-800 bg-opacity-50 lg:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 left-0 z-30 w-64 transform bg-white transition duration-300 ease-in-out lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b border-gray-200 px-6">
          <div className="flex items-center">
            <img 
              src="/logo.png" 
              alt="Elle GE Solar" 
              className="h-8"
            />
          </div>
          <button onClick={toggleSidebar} className="lg:hidden">
            <X size={24} />
          </button>
        </div>

        <nav className="mt-8 px-4">
          <ul className="space-y-2">
            {navigationItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center rounded-lg px-4 py-3 transition-colors ${
                    location.pathname === item.path
                      ? 'bg-primary-500 text-white'
                      : 'text-gray-700 hover:bg-primary-50 hover:text-primary-500'
                  }`}
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </Link>
              </li>
            ))}
          </ul>

          <div className="mt-10 border-t border-gray-200 pt-6">
            <button
              onClick={handleLogout}
              className="flex w-full items-center rounded-lg px-4 py-3 text-gray-700 transition-colors hover:bg-primary-50 hover:text-primary-500"
            >
              <LogOut size={20} />
              <span className="ml-3">Sair</span>
            </button>
            
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="mt-2 flex w-full items-center rounded-lg px-4 py-3 text-gray-700 transition-colors hover:bg-primary-50 hover:text-primary-500"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
              <span className="ml-3">{darkMode ? 'Modo Claro' : 'Modo Escuro'}</span>
            </button>
          </div>
        </nav>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-white shadow">
          <div className="flex h-16 items-center justify-between px-4 lg:px-6">
            <button
              onClick={toggleSidebar}
              className="rounded-lg p-2 text-gray-700 hover:bg-gray-100 lg:hidden"
            >
              <Menu size={24} />
            </button>

            <div className="flex items-center">
              <div className="mr-2 rounded-full bg-primary-100 p-1">
                <Settings size={20} className="text-primary-500" />
              </div>
              <span className="text-sm font-medium text-gray-700">Administrador</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;