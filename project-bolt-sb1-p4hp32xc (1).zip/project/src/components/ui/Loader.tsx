import React from 'react';

interface LoaderProps {
  size?: 'small' | 'medium' | 'large';
  color?: string;
  label?: string;
}

const Loader: React.FC<LoaderProps> = ({ 
  size = 'medium', 
  color = 'text-primary-500', 
  label 
}) => {
  const sizeMap = {
    small: 'h-4 w-4',
    medium: 'h-8 w-8',
    large: 'h-12 w-12',
  };

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative">
        <div className={`${sizeMap[size]} animate-spin rounded-full border-b-2 border-t-2 ${color}`}></div>
      </div>
      {label && (
        <p className="mt-3 text-center text-sm text-gray-500">{label}</p>
      )}
    </div>
  );
};

export default Loader;