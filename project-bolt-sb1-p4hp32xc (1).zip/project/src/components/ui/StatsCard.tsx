import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactElement<LucideIcon>;
  change?: {
    value: number;
    type: 'increase' | 'decrease';
  };
  borderColor?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  icon,
  change,
  borderColor = 'border-primary-500',
}) => {
  return (
    <div className={`dashboard-card border-l-4 ${borderColor}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <h3 className="mt-1 text-2xl font-semibold text-gray-900">{value}</h3>
          
          {change && (
            <div className="mt-2 flex items-center text-sm">
              <span 
                className={`mr-1 ${
                  change.type === 'increase' ? 'text-success-500' : 'text-error-500'
                }`}
              >
                {change.type === 'increase' ? '↑' : '↓'} {Math.abs(change.value)}%
              </span>
              <span className="text-gray-500">comparado ao mês anterior</span>
            </div>
          )}
        </div>
        
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-50">
          {React.cloneElement(icon, { 
            size: 24, 
            className: 'text-primary-500' 
          })}
        </div>
      </div>
    </div>
  );
};

export default StatsCard;