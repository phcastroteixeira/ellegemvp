import React from 'react';

interface DataPoint {
  label: string;
  value: number;
}

interface DataChartProps {
  data: DataPoint[];
  title: string;
  height?: number;
  barColor?: string;
  labelColor?: string;
  animate?: boolean;
}

const DataChart: React.FC<DataChartProps> = ({
  data,
  title,
  height = 200,
  barColor = '#0F4C81',
  labelColor = '#0F4C81',
  animate = true,
}) => {
  const maxValue = Math.max(...data.map(item => item.value));

  return (
    <div className="w-full">
      <h3 className="mb-4 font-medium text-gray-700">{title}</h3>
      <div style={{ height: `${height}px` }} className="mb-2">
        <div className="flex h-full items-end justify-between gap-1">
          {data.map((item, index) => {
            const barHeight = (item.value / maxValue) * 100;
            return (
              <div 
                key={index} 
                className="group relative flex w-full flex-col items-center"
              >
                {/* Tooltip */}
                <div className="pointer-events-none absolute -top-10 z-10 hidden transform rounded bg-gray-800 px-2 py-1 text-xs text-white opacity-0 transition-opacity group-hover:block group-hover:opacity-100">
                  {item.value}
                </div>
                {/* Bar */}
                <div 
                  className="w-full rounded-t transition-all"
                  style={{ 
                    height: `${barHeight}%`, 
                    backgroundColor: barColor,
                    animation: animate ? `growUp 1s ease forwards` : 'none',
                    transformOrigin: 'bottom',
                  }}
                ></div>
                {/* Label */}
                <div 
                  className="mt-2 w-full truncate text-center text-xs font-medium" 
                  style={{ color: labelColor }}
                >
                  {item.label}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <style jsx>{`
        @keyframes growUp {
          from { transform: scaleY(0); }
          to { transform: scaleY(1); }
        }
      `}</style>
    </div>
  );
};

export default DataChart;