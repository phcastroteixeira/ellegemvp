import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';

interface AuthMiddlewareProps {
  children: React.ReactNode;
  requiredRole?: 'admin' | 'client';
}

const AuthMiddleware: React.FC<AuthMiddlewareProps> = ({ children, requiredRole }) => {
  const { isAuthenticated, user } = useAuthStore();
  const location = useLocation();

  // Public paths that don't require authentication
  const publicPaths = ['/login', '/register'];
  const isPublicPath = publicPaths.includes(location.pathname);

  // Check if current path is a public asset
  const isPublicAsset = location.pathname.startsWith('/assets/') || 
                       location.pathname.startsWith('/images/') ||
                       location.pathname === '/favicon.ico';

  if (!isAuthenticated && !isPublicPath && !isPublicAsset) {
    // Save the attempted URL to redirect back after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Role-based access control
  if (isAuthenticated && requiredRole && user?.role !== requiredRole) {
    return <Navigate to={user?.role === 'admin' ? '/admin' : '/'} replace />;
  }

  return <>{children}</>;
};

export default AuthMiddleware;