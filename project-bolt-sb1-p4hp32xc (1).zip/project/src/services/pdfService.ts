import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import { Bill, Customer } from '../types';

export const generateBillPDF = (bill: Bill, customer: Customer) => {
  // Create new PDF document
  const doc = new jsPDF();
  
  // Add logo
  doc.addImage('/logo.png', 'PNG', 15, 10, 60, 20);
  
  // Add header information
  doc.setFontSize(20);
  doc.text('Fatura de Energia', 15, 45);
  
  doc.setFontSize(10);
  doc.text(`Fatura Nº: ${bill.id}`, 15, 55);
  doc.text(`Data de Emissão: ${format(new Date(bill.issueDate), 'dd/MM/yyyy')}`, 15, 60);
  doc.text(`Vencimento: ${format(new Date(bill.dueDate), 'dd/MM/yyyy')}`, 15, 65);
  
  // Add customer information
  doc.setFontSize(12);
  doc.text('Dados do Cliente', 15, 80);
  
  doc.setFontSize(10);
  doc.text(`Nome: ${customer.name}`, 15, 90);
  doc.text(`Unidade Consumidora: ${customer.consumerUnit}`, 15, 95);
  doc.text(`Endereço: ${customer.address}`, 15, 100);
  doc.text(`${customer.city}/${customer.state} - CEP: ${customer.zipCode}`, 15, 105);
  
  // Add consumption information
  doc.setFontSize(12);
  doc.text('Informações de Consumo', 15, 120);
  
  // Create consumption table
  autoTable(doc, {
    startY: 125,
    head: [['Descrição', 'Quantidade', 'Valor Unit.', 'Valor Total']],
    body: [
      [
        'Consumo Próprio',
        `${bill.autoConsumption} kWh`,
        `R$ ${bill.utilityRate.toFixed(3)}`,
        `R$ ${(bill.autoConsumption * bill.utilityRate).toFixed(2)}`
      ],
      [
        'Crédito Recebido',
        `${bill.receivedCredit} kWh`,
        `R$ ${bill.saleValue.toFixed(2)}`,
        `R$ ${(bill.receivedCredit * bill.saleValue).toFixed(2)}`
      ],
      [
        'Taxa de Iluminação Pública',
        '-',
        '-',
        `R$ ${bill.publicLightingFee.toFixed(2)}`
      ],
      [
        'Taxa Mínima',
        '-',
        '-',
        `R$ ${bill.minimumRate.toFixed(2)}`
      ]
    ],
    styles: { fontSize: 10 },
    headStyles: { fillColor: [27, 54, 93] },
  });
  
  // Add reading information
  const finalY = (doc as any).lastAutoTable.finalY || 150;
  
  doc.setFontSize(10);
  doc.text('Período de Leitura:', 15, finalY + 15);
  doc.text(`De: ${format(new Date(bill.initialReadingDate), 'dd/MM/yyyy')}`, 35, finalY + 20);
  doc.text(`Até: ${format(new Date(bill.readingDate), 'dd/MM/yyyy')}`, 35, finalY + 25);
  
  // Add total
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`Valor Total: R$ ${bill.receivedValue.toFixed(2)}`, 15, finalY + 40);
  
  // Add footer
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('Elle GE Solar - Energia Fotovoltaica', 15, 280);
  doc.text('Contato: (11) 9999-9999 | contato@ellegesolar.com.br', 15, 285);
  
  // Save the PDF
  const fileName = `Fatura_${bill.id}_${format(new Date(bill.issueDate), 'dd-MM-yyyy')}.pdf`;
  doc.save(fileName);
};