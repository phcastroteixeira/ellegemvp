import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';
import AuthMiddleware from './middleware/AuthMiddleware';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import AdminLayout from './components/layouts/AdminLayout';
import ClientLayout from './components/layouts/ClientLayout';
import NotFound from './pages/NotFound';
import AdminDashboard from './pages/admin/Dashboard';
import AdminCustomers from './pages/admin/Customers';
import AdminCustomerForm from './pages/admin/CustomerForm';
import AdminBills from './pages/admin/Bills';
import AdminBillForm from './pages/admin/BillForm';
import AdminParameters from './pages/admin/Parameters';
import ClientDashboard from './pages/client/Dashboard';
import ClientBills from './pages/client/Bills';
import ClientProfile from './pages/client/Profile';

const App: React.FC = () => {
  const { user } = useAuthStore();
  
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login" element={
        <AuthMiddleware>
          <Login />
        </AuthMiddleware>
      } />
      <Route path="/register" element={
        <AuthMiddleware>
          <Register />
        </AuthMiddleware>
      } />
      
      {/* Admin routes */}
      <Route path="/admin" element={
        <AuthMiddleware requiredRole="admin">
          <AdminLayout />
        </AuthMiddleware>
      }>
        <Route index element={<AdminDashboard />} />
        <Route path="customers" element={<AdminCustomers />} />
        <Route path="customers/new" element={<AdminCustomerForm />} />
        <Route path="customers/:id" element={<AdminCustomerForm />} />
        <Route path="bills" element={<AdminBills />} />
        <Route path="bills/new" element={<AdminBillForm />} />
        <Route path="bills/:id" element={<AdminBillForm />} />
        <Route path="parameters" element={<AdminParameters />} />
      </Route>
      
      {/* Client routes */}
      <Route path="/" element={
        <AuthMiddleware requiredRole="client">
          <ClientLayout />
        </AuthMiddleware>
      }>
        <Route index element={<ClientDashboard />} />
        <Route path="bills" element={<ClientBills />} />
        <Route path="profile" element={<ClientProfile />} />
      </Route>
      
      {/* Root redirect */}
      <Route path="/" element={
        user?.role === 'admin' ? 
          <Navigate to="/admin" replace /> : 
          <Navigate to="/" replace />
      } />
      
      {/* Not found route */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;