export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'client';
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  consumerUnit: string;
  address: string;
  zipCode: string;
  city: string;
  state: string;
  createdAt: string;
  updatedAt: string;
}

export interface Parameter {
  id: string;
  month: number;
  year: number;
  utilityRate: number;
  publicLightingFee: number;
  saleValue: number; // New field
  minimumRate: number; // New field
  createdAt: string;
  updatedAt: string;
}

export interface Bill {
  id: string;
  customerId: string;
  customer?: Customer;
  month: number;
  year: number;
  autoConsumption: number;
  receivedCredit: number;
  totalReading: number;
  utilityRate: number;
  saleValue: number;
  accumulatedCredit: number;
  receivedValue: number;
  accumulatedValue: number;
  publicLightingFee: number;
  issueDate: string;
  minimumRate: number;
  dueDate: string;
  initialReadingDate: string;
  readingDate: string;
  status: 'pending' | 'paid' | 'overdue';
  paidDate?: string;
  createdAt: string;
  updatedAt: string;
}

export type Month = {
  value: number;
  label: string;
};

export const MONTHS: Month[] = [
  { value: 1, label: 'Janeiro' },
  { value: 2, label: 'Fevereiro' },
  { value: 3, label: 'Março' },
  { value: 4, label: 'Abril' },
  { value: 5, label: 'Maio' },
  { value: 6, label: 'Junho' },
  { value: 7, label: 'Julho' },
  { value: 8, label: 'Agosto' },
  { value: 9, label: 'Setembro' },
  { value: 10, label: 'Outubro' },
  { value: 11, label: 'Novembro' },
  { value: 12, label: 'Dezembro' },
];

export const STATES = [
  { value: 'AC', label: 'Acre' },
  { value: 'AL', label: 'Alagoas' },
  { value: 'AP', label: 'Amapá' },
  { value: 'AM', label: 'Amazonas' },
  { value: 'BA', label: 'Bahia' },
  { value: 'CE', label: 'Ceará' },
  { value: 'DF', label: 'Distrito Federal' },
  { value: 'ES', label: 'Espírito Santo' },
  { value: 'GO', label: 'Goiás' },
  { value: 'MA', label: 'Maranhão' },
  { value: 'MT', label: 'Mato Grosso' },
  { value: 'MS', label: 'Mato Grosso do Sul' },
  { value: 'MG', label: 'Minas Gerais' },
  { value: 'PA', label: 'Pará' },
  { value: 'PB', label: 'Paraíba' },
  { value: 'PR', label: 'Paraná' },
  { value: 'PE', label: 'Pernambuco' },
  { value: 'PI', label: 'Piauí' },
  { value: 'RJ', label: 'Rio de Janeiro' },
  { value: 'RN', label: 'Rio Grande do Norte' },
  { value: 'RS', label: 'Rio Grande do Sul' },
  { value: 'RO', label: 'Rondônia' },
  { value: 'RR', label: 'Roraima' },
  { value: 'SC', label: 'Santa Catarina' },
  { value: 'SP', label: 'São Paulo' },
  { value: 'SE', label: 'Sergipe' },
  { value: 'TO', label: 'Tocantins' },
];